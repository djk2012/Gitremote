package server;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server extends Thread {

    Socket clientSocket = null;
    public DatabaseQuery db = null;
    PrintWriter out = null;
    BufferedReader in = null;
    public Server(Socket clientSocket) {
        this.clientSocket = clientSocket;
        System.out.println("Address: " + clientSocket.getInetAddress().getHostAddress());
        db = new DatabaseQuery();


    }

    public void run() {
       
        boolean ok = true;
        try {
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(
                    clientSocket.getInputStream()));
        } catch (IOException ioe) {
            System.out.println("Failed in creating streams");
            System.exit(-1);
        }
        String inputLine, outputLine;
        try {
            while ((inputLine = in.readLine()) != null) {
                 if (inputLine.equals("Bye")) {
                    break;
                }
                System.out.println("waiting next command");
                String[] messagearr = inputLine.split(":");
                if (messagearr[0].equals("Login")) {
                    String name = messagearr[1];
                    String pass = messagearr[2];
                    String resp = db.validateUser(name, pass);
                    inputLine = resp;
                    out.println(inputLine);
                } else if (messagearr[0].equals("Register")) {
                    String name = messagearr[1];
                    String Password = messagearr[2];
                    String Email = messagearr[3];
                    String Tag = messagearr[4];
                   String image=messagearr[5];
                   String source=messagearr[6];
                   String fav=messagearr[7];
                    out.println("upload image");
                  String imagepath=SaveImage(image);
                   if(!imagepath.equals("false")&&!imagepath.equals("exists"))
                    {
                        String resp=db.Registery(name, Password, Email, Tag, imagepath,source,fav);
                        System.out.println(resp);
                   }
       
                 


                } else if (messagearr[0].equals("Upload Image")) {
                      //out.println("upload image");
                      System.out.println(messagearr[1]);
                      String destpath=messagearr[1];  
                      out.println("start");
                      String imagepath=SaveImage(destpath);
                     
                    
                } else if (messagearr[0].equals("close")) {
                    ok = false;
                } else if (messagearr[0].equals("Upload")) { 
                    String uploader=messagearr[1];
                    String position=messagearr[2];
                    String imagename=messagearr[3];
                    String voicename = messagearr[4];
                    String ISource=messagearr[5];
                    String VSource=messagearr[6];
                    String Tag=messagearr[7];
                   out.println("upload video");
                    String voicepath=SaveVoice(voicename);
                    if(!voicepath.equals("false")&&!voicepath.equals("exists"))
                    {
                        String resp= db.StoreImageAndVoice(uploader,position,System.getProperty("user.dir") + "/Images/"+imagename , voicepath,ISource,VSource,Tag);
                        System.out.println(resp);
                        out.println(resp);
                    }
                    
                }
                else if(messagearr[0].equals("Load Storage"))
                {
                    ArrayList<String> lists=null;
                    String username=messagearr[1];
                    lists=db.readUserStoragedetail(username);
                   System.out.println(lists.size());
                    out.println(lists.size());
                    String s=in.readLine();
                    for(int i=0;i<lists.size();i++)
                    {
                       String ss=lists.get(i).toString();
                       out.println(ss);
                       System.out.println(lists.get(i));
                  }
                  //  System.out.println();
                }
                  else if(messagearr[0].equals("Tag Load"))
                {
                    ArrayList<String> lists=null;
                    String Tagname=messagearr[1];
                    lists=db.readUserStorageByTag(Tagname);
                    System.out.println(lists.size());
                    out.println(lists.size());
                    String s=in.readLine();
                    for(int i=0;i<lists.size();i++)
                    {
                       String ss=lists.get(i).toString();
                       out.println(ss);
                       System.out.println(lists.get(i));
                  }
                  //  System.out.println();
                }
                  
                   else if(messagearr[0].equals("CityTag Load"))
                {
                    ArrayList<String> lists=null;
                    String Tagname=messagearr[1];
                    String Cityname=messagearr[2];
                    lists=db.readUserStorageByTagAndCity(Tagname, Cityname);
                    System.out.println(lists.size());
                    out.println(lists.size());
                    String s=in.readLine();
                    for(int i=0;i<lists.size();i++)
                    {
                       String ss=lists.get(i).toString();
                       out.println(ss);
                       System.out.println(lists.get(i));
                  }
                  //  System.out.println();
                }
                  
                  else if(messagearr[0].equals("City Load"))
                {
                    String ResCitys="";
                    String Tagname=messagearr[1];
                    String locations=db.readUserCity();
                    if(!locations.equals("Empty"))
                    {
                        
                    System.out.println(locations);
                    String location[]=locations.split("~");
                    for(int i=0;i<location.length;i++)
                    {
                        String detail[]=location[i].split(",");
                        ResCitys=ResCitys+detail[1]+"~";
                    }
                       ResCitys=ResCitys.substring(0);
                       System.out.println("send the message: "+ResCitys);
                       out.println(ResCitys);
                    }else{                        
                        out.println(locations);
                        
                    }
                    
                }
                else if(messagearr[0].equals("Load SelfImage"))
                {
                    String filename=messagearr[1];
                    String resp=SendSelfImage(filename);
                    System.out.println(resp);
                    //out.println("ok");
                    
                }
                 else if(messagearr[0].equals("Load Image"))
                {
                    String filename=messagearr[1];
                    String resp=SendImage(filename);
                    System.out.println(resp);
                    //out.println("ok");
                    
                }
                 else if(messagearr[0].equals("Load"))
                {
                    String filename=messagearr[1];
                    String resp=db.readUserDetailFromDatabase(filename);
                    System.out.println(resp);
                    out.println(resp);
                    //out.println("ok");
                    
                }
                else if(messagearr[0].equals("Load Sound"))
                {
                    String filename=messagearr[1];
                    System.out.println("111111111111");
                    String resp=SendSound(filename);
                    System.out.println(resp);
                   //  out.println(resp);
                }else if(messagearr[0].equals("Upload Event"))
                {
                    String name=messagearr[1];
                    String where=messagearr[2];
                    String why=messagearr[3];
                    String start=messagearr[4];
                    String end=messagearr[5];
                    String detail=messagearr[6];
                   String resp=db.StoreEvents(name, where, why, start, end, detail);
                   // String resp=db.StoreEvents("ding", "heibei", "ss", "sss","ss", "cc");
                    System.out.println(resp);
                    out.println(resp);
                }
                 else if(messagearr[0].equals("Load Event"))
                {
                    ArrayList<String> lists=null;
                 //   String username=messagearr[1];
                   lists=db.SendEventlist();
                   System.out.println(lists.size());
                    out.println(lists.size());
                    String s=in.readLine();
                    for(int i=0;i<lists.size();i++)
                    {
                       String ss=lists.get(i).toString();
                       out.println(ss);
                       System.out.println(lists.get(i));
                  }
                }
                 else if(messagearr[0].equals("Edit Info"))
                {
                    String name=messagearr[1];
                    String password=messagearr[2];
                    String email=messagearr[3];
                    String tag=messagearr[4];
                    String fav=messagearr[5];
                    String resp=db.updateUserInfoDataBase(name, password, email, tag, fav);
                    out.println(resp);                   
                }
                 else if(messagearr[0].equals("Comment"))
                {
                    String name=messagearr[1];
                    String fullname=System.getProperty("user.dir") + "/Images/"+name;
                    String resp=db.updateImageComment(fullname);
                    System.out.println("the comment result :"+resp);
                    int comment=db.getCurrentComment(fullname);
                    out.println(comment+"");                   
                }
                System.out.println(" server has received:" + inputLine);
               
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            System.exit(-1);
        }
        try {
            clientSocket.close();
            out.close();
            in.close();
        } catch (IOException ioe) {
            System.out.println("Failed in closing down");
            System.exit(-1);
        }
    }

    public String SaveImage(String filename) {
        try {
            DataInputStream inputFromServer = new DataInputStream(clientSocket.getInputStream());
            byte[] size = new byte[1024];
            File destfile = new File(System.getProperty("user.dir") + "/Images/" + filename);
            if (!destfile.exists()) {
                FileOutputStream out = new FileOutputStream(destfile);
                long ss = 0;
                int c = -1;
                while ((c = inputFromServer.read(size)) != -1) {
                    out.write(size, 0, c);                                       
                }
                out.close();
                System.out.println("the image has been saved");
                return System.getProperty("user.dir") + "/Images/" + filename;
            }else{
                return "exists";
            }

            }  catch (Exception ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
         return "false";
    }
    public  String SendSelfImage(String Username)
    {
               DataOutputStream outs;
		try {
		outs = new DataOutputStream(clientSocket.getOutputStream());
		byte[] size = new byte[1024];
		File destfile = new File(System.getProperty("user.dir") + "/Images/"+Username+".jpg");
          
		if (destfile.exists()) {
                     long flength=destfile.length();
                     String z=in.readLine();
                     if(z.equals("ok")){
                        outs.writeLong(flength);
			FileInputStream ins = new FileInputStream(destfile);
			long ss = 0;
			int c = -1;
			while ((c = ins.read(size)) != -1) {
				outs.write(size,0, c);
				ss = ss + c;
				

			}
                        
			ins.close();
			return "successfully upload"+ss;
                     }else{
                         //out.println("no need");
                         return "successfully ";
                     }
			
		}
		
    }catch(Exception ex)
	{
	 ex.printStackTrace() ;
	}
		return "error";
    
    }
       public  String SendImage(String Imagename)
    {
               DataOutputStream outs;
		try {
		outs = new DataOutputStream(clientSocket.getOutputStream());
		byte[] size = new byte[1024];
		File destfile = new File(System.getProperty("user.dir") + "/Images/"+Imagename);
          
		if (destfile.exists()) {
                     long flength=destfile.length();
                     String z=in.readLine();
                     if(z.equals("ok")){
                        outs.writeLong(flength);
			FileInputStream ins = new FileInputStream(destfile);
			long ss = 0;
			int c = -1;
			while ((c = ins.read(size)) != -1) {
				outs.write(size,0, c);
                                ss=ss+c;
			}
                        
			ins.close();
			return "successfully upload"+ss;
                     }else{
                         return "successfully ";
                     }
			
		}
		
    }catch(Exception ex)
	{
	 ex.printStackTrace() ;
	}
		return "error";
    
    }
    public  String SendSound(String soundname)
    {
               DataOutputStream outs;
		try {
		outs = new DataOutputStream(clientSocket.getOutputStream());
		byte[] size = new byte[1024];
		File destfile = new File(System.getProperty("user.dir") + "/Voices/"+soundname+".mp3");
          
		if (destfile.exists()) {
                    long flength=destfile.length();
                    System.out.println("find it.............");
                     String z=in.readLine();
                     if(z.equals("ok")){
                        outs.writeLong(flength);
			FileInputStream ins = new FileInputStream(destfile);
			long ss = 0;
			int c = -1;
                        System.out.println("soon transfore");
			while ((c = ins.read(size)) != -1) {
				outs.write(size,0,c);
                                ss=ss+c;
			}   
			ins.close();
			return "successfully upload"+ss;
                     }else{
                         return "successfully ";
                     }			
		}		
    }catch(Exception ex)
	{
	 System.out.println(ex.getMessage()) ;
	}
		return "error";
    
    }
     public String SaveVoice(String filename) {
        try {
            DataInputStream inputFromServer = new DataInputStream(clientSocket.getInputStream());
            byte[] size = new byte[1024];
            File destfile = new File(System.getProperty("user.dir") + "/Voices/" + filename);
            if (!destfile.exists()) {
                FileOutputStream out = new FileOutputStream(destfile);
                long ss = 0;
                int c = -1;
                while ((c = inputFromServer.read(size)) != -1) {
                    out.write(size, 0, c);              
                    ss=ss+c;
                }
                out.close();
               // inputFromServer.close();
                System.out.println("the image has been saved"+ss);
                return System.getProperty("user.dir") + "/Voices/" + filename;
            }else{
                return "exists";
            }

            }  catch (Exception ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
         return "false";
    }
}
