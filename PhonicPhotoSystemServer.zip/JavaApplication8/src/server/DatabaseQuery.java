package server;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mysql.jdbc.*;

/*
 **********************************************************************************************
 * Authors : Zakir Hossain, Mathias Olsson, Hanna Persson, 
 * 
 * Class : DatabaseQuery
 * 
 * Class functionality : All database functionality..creating, query, savaing ,updating						
 * 							
 * ********************************************************************************************
 */
public class DatabaseQuery {

    /*
     * Simplified method for Creating database, 
     * This method will check for database on localhost. if its find the database will work normally. 
     * otherwise it will create a database with table and data.
     */
    
    public DatabaseQuery()
    {
    }
    public String Registery(String name,String Password,String Email,String Tag,String image,String Source,String fav) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856");
            Statement st = con.createStatement();
            String query="Insert into users (UserName,PassWord,Email,Tag,SelfImage,Source,Favorite)values('"+name+"','"+Password+"','"+Email+"','"+Tag+"','"+image+"','"+Source+"','"+fav+"');";
            st.executeUpdate(query);
            System.out.println("Databases has been updated, a row has been save in users");
            con.close();
            return "Successfully register";
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Error encountered. : " + ex.getMessage();
        } 
    }
     public String StoreImageAndVoice(String name,String Location,String image,String voice,String ISource,String VSource,String Tag) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856");
            Statement st = con.createStatement();
            String query="Insert into storage (UserName,Location,Images,Videos,ISource,VSource,Comment,Tag)values('"+name+"','"+Location+"','"+image+"','"+voice+"','"+ISource+"','"+VSource+"',0,'"+Tag+"');";
            st.executeUpdate(query);
            System.out.println("Databases has been updated, a row has been save in storage");
            con.close();
            return "Successfully Stored";
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Error encountered. : " + ex.getMessage();
        } 
    }
      public String StoreEvents(String name,String where,String why,String start,String end,String detail) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856");
            Statement st = con.createStatement();
         //   String query="Insert into event (Builder,Destination,Reason,Start,End,Specific) values('"+name+"','"+where+"','"+why+"','"+start+"','"+end+"','"+detail+"');";
            int index= getAvailableposition("event");
            String query="Insert into event values("+index+",'"+name+"','"+where+"','"+why+"','"+start+"','"+end+"','"+detail+"');";
            st.executeUpdate(query);
            System.out.println("Databases has been updated, a row has been save in event");
            con.close();
            return "Successfully Stored";
        } catch (Exception ex) {
            ex.printStackTrace();
            return "Error encountered. : " + ex.getMessage();
        } 
    }


    /*
     * Simplified method for updating database, only works in the current state
     * of the project. Requires updates for further development of the project.
     */
   
    
       public String updateUserInfoDataBase(String name,String password, String email,String tag,String fav) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();
            String query = "UPDATE users SET PassWord='" + password+ "',Email='"+email+"',Tag='"+tag+"',Favorite='"+fav+"' WHERE UserName='" +  name+ "'";
            st.executeUpdate(query);
            System.out.println("Database updated : user "+name+" personal information has been saved");
            con.close();
            return "Successfully";
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return "false";
    }
    /*
     * read all data from database and return an arraylist 
     * 
     * Now this method will return an ArrayList instead of String 
     */

    public String readUserDetailFromDatabase(String username) {
       
        String userdetail="false";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM users where UserName='"+username+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail = rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3)+":"+rs.getString(4)+":"+rs.getString(5)+":"+rs.getString(6)+":"+rs.getString(7)+":"+rs.getString(8);                
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return userdetail;
    }
      public ArrayList<String> readUserStoragedetail(String username) {
       
       ArrayList<String> lists= new ArrayList<String>();
       String userdetail="false";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM storage where UserName='"+username+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail = rs.getString("UserName")+"~"+rs.getString("Location")+"~"+rs.getString("Images")+"~"+rs.getString("Videos")+"~"+rs.getString("ISource")+"~"+rs.getString("VSource")+"~"+rs.getInt("Comment")+"~"+rs.getString("Tag");        
                lists.add(userdetail);
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return lists;
    }
     public ArrayList<String> readUserStorageByTag(String Tag) {      
       ArrayList<String> lists= new ArrayList<String>();
       String userdetail="false";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM storage where Tag='"+Tag+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail = rs.getString("UserName")+"~"+rs.getString("Location")+"~"+rs.getString("Images")+"~"+rs.getString("Videos")+"~"+rs.getString("ISource")+"~"+rs.getString("VSource")+"~"+rs.getInt("Comment")+"~"+rs.getString("Tag");        
                lists.add(userdetail);
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return lists;
    }
    public ArrayList<String> readUserStorageByTagAndCity(String Tag,String city) {      
       ArrayList<String> lists= new ArrayList<String>();
       String userdetail="false";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM storage where Tag='"+Tag+"'and Location LIKE '"+"%"+city+"%"+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail = rs.getString("UserName")+"~"+rs.getString("Location")+"~"+rs.getString("Images")+"~"+rs.getString("Videos")+"~"+rs.getString("ISource")+"~"+rs.getString("VSource")+"~"+rs.getInt("Comment")+"~"+rs.getString("Tag");        
                lists.add(userdetail);
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return lists;
    }
    
    public String readUserCity () {      
       
       String userdetail="";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM storage;";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail =userdetail+rs.getString("Location")+"~";
                
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        if(userdetail==null)
        {
            return "Empty";
        }
        return userdetail;
    }
     public String updateImageComment(String name) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();
            int comment=getCurrentComment(name)+1;
            String query = "UPDATE storage SET Comment=" + comment+ " WHERE Images='" +  name+ "'";
            st.executeUpdate(query);
            System.out.println("Database updated : comment has been saved");
            con.close();
            return "Successfully";
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return "false";
    }
      public int getCurrentComment(String name) {
           int comment=-1;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT  * FROM storage WHERE Images='" + name + "';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {               
                comment = rs.getInt("Comment");                
                   return comment; 
            }  
           
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return -1;
    }
   public ArrayList<String> SendEventlist() {       
       ArrayList<String> lists= new ArrayList<String>();
       String userdetail="false";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * FROM event;";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                userdetail = rs.getString("Builder")+"~"+rs.getString("Destination")+"~"+rs.getString("Reason")+"~"+rs.getString("Start")+"~"+rs.getString("End")+"~"+rs.getString("Specific");        
                lists.add(userdetail);
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return lists;
    }

    public String validateUser(String user, String pass) {
        String dbUser = null, dbPass = null, dbAccess = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT  PassWord FROM users WHERE UserName='" + user + "';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {               
                dbPass = rs.getString("PassWord");       
                if(pass.equals(dbPass))
                {
                   return readUserDetailFromDatabase(user); 
                }
            }  
           
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return "false";
    }
    public int getAvailableposition(String tablename)
    {
        int count=-1;
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from "+tablename+";";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   count=rs.getInt("Id");
                   System.out.println("当前id"+count);
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return count+1;
    }
     public ArrayList<String> getUserStorageImage(String username)
    {
        ArrayList<String> imagelist = new ArrayList<String>();
        String  Image=null;
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage where UserName='"+username+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   Image=rs.getString("Images");
                   imagelist.add(Image);
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return imagelist;
    }
       public String getUserStorageImageSource(String ImageSource)
    {
       
        String  Sourcepath="NOT FOUND";
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage where Image='"+ImageSource+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   Sourcepath=rs.getString("ISource");
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return Sourcepath;
    }
     
     
     
     
     public ArrayList<String> getUserStoragevideo(String username)
    {
        ArrayList<String> videolist = new ArrayList<String>();
        String  video=null;
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage where UserName='"+username+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   video=rs.getString("Videos");
                   videolist.add(video);
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return videolist;
    }
      public String getUserStoragevideoSource(String videopath)
    {
        
        String  vpath="NOT FOUND";
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage where Videos='"+videopath+"';";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   vpath=rs.getString("VSource");
                   
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return vpath;
    }
     
      public ArrayList<String> getStorageImage()
    {
        ArrayList<String> imagelist = new ArrayList<String>();
        String  Image=null;
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage;";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   Image=rs.getString("Images");
                   imagelist.add(Image);
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return imagelist;
    }
        public ArrayList<String> getStoragevideo()
    {
        ArrayList<String> videolist = new ArrayList<String>();
        String  video=null;
         try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1/degreedb?user=root&password=8856";
            Connection con = DriverManager.getConnection(url);
            Statement st = con.createStatement();

            String query = "SELECT * from storage;";
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                   video=rs.getString("Videos");
                   videolist.add(video);
                   
            }                     
        } catch (Exception e) {
            System.out.println("Error encountered. : " + e.getMessage());
        }
        return videolist;
    }

  
}
