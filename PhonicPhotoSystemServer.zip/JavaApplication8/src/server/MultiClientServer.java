package server;

import java.io.*;
import java.net.*;

public class MultiClientServer extends Thread {
	public static void main(String[] args) {
		MultiClientServer multiClientServer = new MultiClientServer();
		multiClientServer.start();
	}

	public void run() {
		ServerSocket serverSocket = null;
		try {
			serverSocket = new ServerSocket(1234);
                        System.out.println("the Server is running....");
		} catch (IOException e) {
			System.out.println("Could not listen on port: 2345");
			System.exit(-1);
		}
		Socket clientSocket = null;
		while (true) {
			try {
				clientSocket = serverSocket.accept();
                                System.out.println("a client is connected.."+clientSocket.getPort());
				Server server = new Server(clientSocket);
				server.start();
			} catch (IOException e) {
				System.out.println("Accept failed: 2345");
				System.exit(-1);
			}
		}
	}
}
