package com.example.PhonicPhoto;
import java.util.ArrayList;
import java.util.HashMap;

import com.example.degreeprojectandroid.R;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class LoginActivity extends Activity {
    public  EditText nametv=null;
    public  EditText passtv=null;
    public static Connection con=null;
    public static String LOGINNAME=null;
    public static String POSITION=null;
    public GridView gridview=null;
    public static String detailuser [];
    public static boolean SelftAccess=true;
    public static String Selfname=null;
    public String [] menuchoice=new String[]{"Register","Log In"};
    public int [] menuimages=new int []{R.drawable.add_person,R.drawable.menu_login};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		LinearLayout downlayout = (LinearLayout) super.findViewById(R.id.logindownlayout) ;
		
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		
		this.nametv=(EditText) this.findViewById(R.id.loginnameet);
		this.passtv=(EditText) this.findViewById(R.id.loginpasset);
		this.nametv.setText("gao");
		this.passtv.setText("123456789");
		
		this.gridview=new GridView(this);
		gridview.setNumColumns(2);
		gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
		gridview.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arg2==0)
				{
					startActivity(new Intent(LoginActivity.this,RegisterActivity .class));
				}else if(arg2==1)
				{
					con=con.getConnection();
					con.setResult("Login:"+nametv.getText().toString()+":"+passtv.getText().toString());
					String response=con.getResult();
					if(!response.equals("false"))
					{
					LOGINNAME=nametv.getText().toString();
					detailuser =response.split(":");				
					startActivity(new Intent(LoginActivity.this,MainActivity .class));
					}
					else{
						Toast.makeText(getApplicationContext(),"Login Failed,please try again" , 10000).show();
					}
				}
				}
				
			});
		  
		downlayout.addView(gridview, param);
	}
	 private SimpleAdapter getMenuAdapter(String[] menuNameArray,
	            int[] imageResourceArray) {
	        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
	        for (int i = 0; i < menuNameArray.length; i++) {
	            HashMap<String, Object> map = new HashMap<String, Object>();
	            map.put("itemImage", imageResourceArray[i]);
	            map.put("itemText", menuNameArray[i]);
	            data.add(map);
	        }
	        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
	                R.layout.item_menu, new String[] { "itemImage", "itemText" },
	                new int[] { R.id.item_image, R.id.item_text });
	        return simperAdapter;
	    }
}
