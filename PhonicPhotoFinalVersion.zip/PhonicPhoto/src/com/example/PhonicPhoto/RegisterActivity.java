package com.example.PhonicPhoto;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.format.Time;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class RegisterActivity extends Activity {
	private static int LOAD_IMAGE = 1;
	public static boolean RegChose=false;
	public EditText regname=null;
	public EditText regpass=null;
	public EditText regemail=null;
	public EditText regtag=null;
	public EditText favtag=null;
	public static Connection con=null;
	public Button regconfir,regback,regclear,regtake=null;
	public ImageView regimage=null;
	public static String IMAGEFILE=null;
	public GridView gridview=null;
    public String [] menuchoice=new String[]{"Profile Photo","Save","Clean","Go Back"};
    public int [] menuimages=new int []{android.R.drawable.ic_menu_camera,R.drawable.menu_save,R.drawable.menu_discard,R.drawable.menu_return};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		
		LinearLayout downlayout = (LinearLayout) super.findViewById(R.id.Regdownlayout) ;
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);

		
		this.regname=(EditText) this.findViewById(R.id.Regnameet);
		this.regpass=(EditText) this.findViewById(R.id.Regpasset);
		this.regemail=(EditText) this.findViewById(R.id.Regemailet);
		this.regtag=(EditText) this.findViewById(R.id.Regtaget);
		this.favtag=(EditText) this.findViewById(R.id.Regfavet);
		this.regimage=(ImageView) this.findViewById(R.id.regimageiv);
		
		
		
		gridview=new GridView(this);
		gridview.setNumColumns(2);
		gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
		gridview.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arg2==0)
				{
      Toast.makeText(getApplicationContext(), "You have clicked", 1000);
      System.out.println("You have clicked");
       AlertDialog.Builder dialog=new AlertDialog.Builder(RegisterActivity.this); 
       dialog.setTitle("Chose").setIcon(android.R.drawable.ic_dialog_info).setMessage("Do you want to chose Local or take photo?")
      .setPositiveButton("Chose Local", new DialogInterface.OnClickListener() {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			Intent i = new Intent(
					Intent.ACTION_PICK,
					android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
			RegChose=true;
			startActivityForResult(i, LOAD_IMAGE);
			
		} 
		
    }).setNegativeButton("Take new Photo", new DialogInterface.OnClickListener(){

		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			RegChose=false;
			Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		    startActivityForResult(intent, 1);
		}
		
    }).create().show();

				    
					
				}else if(arg2==1)
				{
					if(IMAGEFILE!=null)
					{
					 boolean passt=	TestPassword(regpass.getText().toString());
					 if(passt==false)
					 {
						Toast.makeText(getApplicationContext(), "Password is not valid,Register failed", 10000).show(); 
					 }else{
					 con = con.getConnection();
					// Toast.makeText(getApplicationContext(),"������" , 10000).show();
					 con.setResult("Register:"+regname.getText().toString()+":"+regpass.getText().toString()+":"+regemail.getText().toString()+":"+regtag.getText().toString()+":"+regname.getText().toString()+".jpg"+":"+IMAGEFILE+":"+favtag.getText().toString());
					 if(con.getResult().equals("upload image"))
					 {
						String imresp= uploadImage(IMAGEFILE);
						Toast.makeText(getApplicationContext(),con.getResult() , 10000).show();
						
					 }	
					 try {
						con.closeSocket();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 }
					}else{
						Toast.makeText(getApplication(), "You can not miss the profile photo,please try again", 10000).show();
					}
				}
				else if(arg2==2)
				{
					  regname.setText("");
				      regpass.setText("");
				      regemail.setText("");
				      regtag.setText("");
				      favtag.setText("");
				}else if(arg2==3)
				{
					startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
				}
//				else if(arg2==4){
//					Intent i = new Intent(
//							Intent.ACTION_PICK,
//							android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//					RegChose=true;
//					startActivityForResult(i, LOAD_IMAGE);
//				}
				
				
			}});
		
		downlayout.addView(gridview, param);

	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if(RegChose==false)
		{
		if (resultCode == Activity.RESULT_OK) {
			String sdStatus = Environment.getExternalStorageState();
			Bundle bundle = data.getExtras();
			Bitmap bitmap = (Bitmap) bundle.get("data");
			Toast.makeText(getApplicationContext(),"show new image" , 10000).show();		
			FileOutputStream b = null;
			File file = new File("/sdcard/myphoto/");
			file.mkdirs();
			String  fileName = "/sdcard/myphoto/" +regname.getText() + ".jpg";
			IMAGEFILE=fileName;
			try {
				b = new FileOutputStream(fileName);
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					b.flush();
					b.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			((ImageView) findViewById(R.id.regimageiv)).setImageBitmap(bitmap);
		 }
		}else if(RegChose==true)
		{
			 if (requestCode == LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
					Uri selectedImage = data.getData();
					String[] filePathColumn = { MediaStore.Images.Media.DATA };

					Cursor cursor = getContentResolver().query(selectedImage,
							filePathColumn, null, null, null);
					cursor.moveToFirst();

					int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
					String picturePath = cursor.getString(columnIndex);
					Toast.makeText(getApplication(), "the picture path is:"+picturePath, 10000).show();
					cursor.close();
					Toast.makeText(getApplicationContext(), "the image Paht is:"+picturePath, 10000).show();
					IMAGEFILE=picturePath;
					((ImageView) findViewById(R.id.regimageiv)).setImageBitmap(BitmapFactory.decodeFile(picturePath));
					RegChose=false;
			 }
					
		}
	}
	 private SimpleAdapter getMenuAdapter(String[] menuNameArray,
	            int[] imageResourceArray) {
	        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
	        for (int i = 0; i < menuNameArray.length; i++) {
	            HashMap<String, Object> map = new HashMap<String, Object>();
	            map.put("itemImage", imageResourceArray[i]);
	            map.put("itemText", menuNameArray[i]);
	            data.add(map);
	        }
	        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
	                R.layout.item_menu, new String[] { "itemImage", "itemText" },
	                new int[] { R.id.item_image, R.id.item_text });
	        return simperAdapter;
	    }
	public static String uploadImage(String imagepath)
    {
		DataOutputStream out;
		try {
			out = new DataOutputStream(
					Connection.socket.getOutputStream());
		byte[] size = new byte[1024];
		File destfile = new File(imagepath);

		if (destfile.exists()) {
			FileInputStream ins = new FileInputStream(destfile);

			long ss = 0;
			int c = -1;
			while ((c = ins.read(size)) != -1) {
				out.write(size, 0, c);
				ss = ss + c;
				

			}
			ins.close();
			out.close();
			return "successfully upload";
			
		}
		
    }catch(Exception ex)
	{
	 ex.printStackTrace() ;
	}
		return "error";
    }
	
	public boolean TestPassword(String password)
	{
		if(password.length()<7)
		{
			Toast.makeText(getApplicationContext(), "Password invalid,Password length should at least 7 ", 10000).show();
			return false;
		}
		
		
		for(int i=0;i<password.length();i++)
		{
			boolean at=testalbum(password.charAt(i));
			boolean nt=testnumber(password.charAt(i));
			if(at==false&nt==false)
			{
				Toast.makeText(getApplicationContext(), "Sorry,Password must only number or uppercase english letter ", 10000).show();
				return false;
			}
		}
		
		
		
		return true;
		
	}
	public boolean testalbum(char a)
	{
		char album[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		for(int i=0;i<album.length;i++)
		{
			if(a==album[i])
			{
				return true;
			}
			
		}
		return false;
	}
	public boolean testnumber(char n)
	{
		char number[]={'0','1','2','3','4','5','6','7','8','9'};
		
		for(int i=0;i<number.length;i++)
		{
			if(n==number[i])
			{
				return true;
			}
		}
		return false;
	}
    
	

}
