package com.example.PhonicPhoto;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.example.PhonicPhoto.PullDownListView.ListViewTouchEventListener;
import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



public class EventshowActivity extends  Activity implements ListViewTouchEventListener  {
	
	
	
	private PullDownListView listView;
	private SimpleAdapter recordSimpleAdapter = null; 	
	public TextView info=null;
	public ListView reclist=null;
	public Connection con=null;
	public ArrayList<String> eventlist=null;
	Map<String, Object> fileInfo =null;
	public static String EventINFO=null;
	public ArrayList<String> elist=null;
	public ArrayList<Map<String,Object>> recordFiles;
	public Button gbbt=null;
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.eventshow);
	        this.reclist = (ListView) super.findViewById(R.id.neweventshowlist);
	        this.info=(TextView) this.findViewById(R.id.EventInfo);
	        listView = new PullDownListView(this);
	        listView.setListViewTouchListener(this);
	      
	        getRecordFiles();
	        //setItems in listview
	    }
	
	@Override
	public void onListViewPulledDown() {
		// TODO Auto-generated method stub
		Log.i("PullDownListViewActivity", "ListView pulled down");
		getRecordFiles();
	}
	private void getRecordFiles() { 						// ȡ��ȫ��¼���ļ�
		this.recordFiles = new ArrayList<Map<String, Object>>(); // ʵ����List����
		elist=new ArrayList<String>();
		con=Connection.getConnection();
		con.setResult("Load Event"+":"+LoginActivity.LOGINNAME);
		int count=Integer.parseInt(con.getResult().trim());
		con.setResult("continue");	
		for(int i=0;i<count;i++)
		{
	    String ss=con.getResult();
	    String ok=getAvailabeshow(ss);
	    if(ok.equals("true"))
	    {
	    fileInfo=new HashMap<String,Object>();
	    String [] basic=ss.split("~");
	    fileInfo.put("eventitem", "Builder is :"+basic[0]+"\n"+"Destination is :"+basic[1]+"\n"+"Reason is :"+basic[2]);
	    this.recordFiles.add(fileInfo);
	    elist.add(ss);
		//Toast.makeText(getApplicationContext(),"a event inserted :"+ss, 10000).show();	
	    }
		}
		this.recordSimpleAdapter = new SimpleAdapter(this,
				this.recordFiles, R.layout.eventshow,
				new String[] { "eventitem" }, 
				new int[] { R.id.EventInfo});			
	this.reclist.setAdapter(this.recordSimpleAdapter); 
	this.reclist.setOnItemClickListener(
			new OnItemClickListenerImpl());
		
	}
	public String getAvailabeshow(String ss)
	{
		String response="false";
		Calendar calendar = Calendar.getInstance(); 
		int year=calendar.get(Calendar.YEAR); 
        int mouth= calendar.get(Calendar.MONTH)+1;
        int day=calendar.get(Calendar.DAY_OF_MONTH);
         
		String []col=ss.split("~");
		String endtime[] =col[col.length-2].split("/");
		
	    int syear=Integer.parseInt(endtime[0]);
	    int smouth=Integer.parseInt(endtime[1]);
	    int sday=Integer.parseInt(endtime[2]);
	    
	    int numyear=syear-year;
	    System.out.println("the Result year is from"+syear+"to :"+year+"----<"+numyear);
	    int nummouth=smouth-mouth;
	    System.out.println("the Result mouth is from"+smouth+"to :"+mouth+"----<"+nummouth);
	    int numday=sday-day;
	    System.out.println("the Result day is from"+sday+"to :"+day+"----<"+numday);
	    if(numyear>=0)
	    {
	    	if(nummouth>=0)
	    	{
	    		if(numday>=0)
	    		{
	    			response="true";
	    			//Toast.makeText(getApplicationContext(),"true:"+ss, 10000).show();
	    			return response;
	    		}
	    	}
	    }	    
	   // Toast.makeText(getApplicationContext(),"false:"+ss, 10000).show();	
		return response;
		
	}
	private class OnItemClickListenerImpl implements OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> adapter, View view,
				int position, long id) {							
			if (EventshowActivity.this.recordSimpleAdapter.
					getItem(position) instanceof Map) {				
				
				EventINFO=elist.get(position);
				startActivity(new Intent(EventshowActivity.this,EventDetailActivity.class));
			}
		}
	}
	
		
		
	

}
