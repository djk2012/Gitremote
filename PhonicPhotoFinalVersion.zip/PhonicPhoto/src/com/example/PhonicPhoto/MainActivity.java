package com.example.PhonicPhoto;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.degreeprojectandroid.R;
import com.example.degreeprojectandroid.R.drawable;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.QuickContactBadge;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {
	public Button photobt,recordbt,locationbt,eventbt,listsbt,logoutbt,searchbt,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21=null;
	public  ImageButton iv=null;
	Connection con = null;
	public ArrayList<String> lists=null;
	private List<Map<String, Object>> recordFiles = null;
	private File recordAudioSaveFileDir = null;
	private boolean sdcardExists = false;	
	Map<String, Object> fileInfo =null;
	private String recDir = "Soundsave";	
	public Map<?, ?> map=null;
	private SimpleAdapter recordSimpleAdapter = null;
	private ListView reclist = null; 
	public String filename=null;
	public static String savesoundpath=null;
	public static String SelectedImage=null;
	public static String SelectedVideo=null;
	public static String SelectedInfo=null;
	public static String MainPhoto=null;
	public static String userphoto=null;
	public static int Selectindex=0;
	DataInputStream inputFromServer=null;
	 public ScrollerLinearLayout sideSlideLayout;
	 public ScrollerLinearLayout leftSlideLayout;
     public ImageView topiv=null;
    // public ListView Menulist=null;
     public GridView gridview=null;
     public String [] menuchoice=new String[]{"Photo","Activity","Search","Log out"};
     public int [] menuimages=new int []{android.R.drawable.ic_menu_camera,android.R.drawable.ic_menu_myplaces,R.drawable.menu_search,R.drawable.menu_quit};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainface);
		
		LinearLayout toplayout = (LinearLayout) super.findViewById(R.id.toplayout) ;
		LinearLayout layout = (LinearLayout) super.findViewById(R.id.rightlayout) ;
		LinearLayout leftlayout = (LinearLayout) super.findViewById(R.id.leftlayout) ;
		
		
		LinearLayout.LayoutParams topparam = new LinearLayout.LayoutParams(
				480,
				100);
		this.topiv=new ImageView(this);		 
		topiv.setImageResource(R.drawable.logo);
		toplayout.addView(topiv, topparam);
	
		
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);

			 this.iv=new ImageButton(this);
			 iv.setMaxWidth(100);
			 iv.setMaxHeight(100);
			 iv.setOnClickListener(new OnClickListener(){

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(LoginActivity.SelftAccess==true)
						{
						startActivity(new Intent(MainActivity.this, Userdetail.class));
						}else{
							//LoginActivity.SelftAccess=true;
							startActivity(new Intent(MainActivity.this, Userdetail.class));
						}
					}
					
				});
			 
			   gridview=new GridView(this);
			   gridview.setNumColumns(1);
			   gridview.setBackgroundColor(Color.GRAY);
			   gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
			   gridview.setOnItemClickListener(new OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					// TODO Auto-generated method stub
					if(LoginActivity.SelftAccess==true)
					{
					   if(arg2==0)
						{
							startActivity(new Intent(MainActivity.this, PhotoActivity.class));
						}else if(arg2==1)
						{
							startActivity(new Intent(MainActivity.this, EventFormActivity.class));
						}else if(arg2==2)
						{
							
							startActivity(new Intent(MainActivity.this, SearchActivity.class));
						}
						else if(arg2==3)
						{
							try {
								con.closeSocket();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							startActivity(new Intent(MainActivity.this, LoginActivity.class));
							
						}	
				 }
				}
				   
			   });

			    leftlayout.addView(iv,param);
			    leftlayout.addView(gridview,param);
	    this.sideSlideLayout = (ScrollerLinearLayout) findViewById(R.id.menu_content_side_slide_layout);
	    leftSlideLayout=(ScrollerLinearLayout) this.findViewById(R.id.menu_content_left_slide_layout);	
	layout.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(),"MOVE Right x:"+event.getX()+" Y:"+event.getY(), 10000).show();
				
				if((int)event.getX()<30)
				{
					leftSlideLayout.scroll();
				}
				else if((int)event.getX()>30 && (int)event.getX()<=175){
					leftSlideLayout.scroll();
				}
				return false;
			}
			
			
		});
	
//	leftlayout.setOnTouchListener(new OnTouchListener(){
//
//			@Override
//			public boolean onTouch(View v, MotionEvent event) {
//				// TODO Auto-generated method stub
//				Toast.makeText(getApplicationContext(),"MOVE Left x:"+event.getX()+" Y:"+event.getY(), 10000).show();
//				
//				if((int)event.getX()>70)
//				{
//				//sideSlideLayout.scroll();
//				//leftSlideLayout.scroll();
//				sideSlideLayout.scroll();
//				
//				
//				}
//				return false;
//			}
//			
//			
//		}); 
	
	
		if (this.sdcardExists = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) { 				// �ж�SD���Ƿ����
			this.recordAudioSaveFileDir = new File(Environment
					.getExternalStorageDirectory().toString()
					+ File.separator
					+ recDir + File.separator); // ����¼��Ŀ¼
		
			if (!this.recordAudioSaveFileDir.exists()) { 	// ���ļ��в�����
				this.recordAudioSaveFileDir.mkdirs(); 		// �����µ��ļ���
			}
			savesoundpath=Environment
					.getExternalStorageDirectory().toString()
					+ File.separator
					+ recDir + File.separator;
		}
		
		
		
		 
		con=Connection.getConnection();
		 try {
				inputFromServer = new DataInputStream(con.socket.getInputStream());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		 String path=null;
		 if(LoginActivity.SelftAccess==true)
		 {
		 con.setResult("Load SelfImage"+":"+LoginActivity.LOGINNAME);
		  path=downloadSelfImage(LoginActivity.LOGINNAME);
		 }else{
			 con.setResult("Load SelfImage"+":"+LoginActivity.Selfname);
			  path=downloadSelfImage(LoginActivity.Selfname);
		 }
		
		if(!path.equals("error"))
		{
		Bitmap bitmap = BitmapFactory.decodeFile(path);  
		
		
		int width = bitmap.getWidth();
	    int height = bitmap.getHeight();
	    
	    int newWidth = 150;
	    int newHeight = 150;
	    
	    float scaleWidth = ((float) newWidth) / width;
	    float scaleHeight = ((float) newHeight) / height;
	    
		Matrix matrix = new Matrix();
	    matrix.postScale(scaleWidth, scaleHeight);
	    
	    Bitmap newbitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix,
	    	      true);
		
		
		
		
		
		
		userphoto=path;
		
        iv.setImageBitmap(newbitmap);  
      //  Toast.makeText(getApplicationContext(),"show it " , 10000).show();
		}else{
			Bitmap bitmap = BitmapFactory.decodeFile("/sdcard/myImage/ding.jpg");  
			
	        iv.setImageBitmap(bitmap);  
			Toast.makeText(getApplicationContext(),"can not find " , 10000).show();
		}
		
		
		
		
		lists=new ArrayList<String>();
		if(LoginActivity.SelftAccess==true)
		{
		con.setResult("Load Storage"+":"+LoginActivity.LOGINNAME);
		}else{
			con.setResult("Load Storage"+":"+LoginActivity.Selfname);	
		}
		int count=Integer.parseInt(con.getResult().trim());
		con.setResult("continue");	
		for(int i=0;i<count;i++)
		{
	    String ss=con.getResult();
		lists.add(ss);
		}
		for (int x = 0; x < lists.size(); x++) {
			
			//click=new String[lists.size()];
			
			final String [] detail=lists.get(x).split("~");
					
			final ImageButton but = new ImageButton(this) ;	
			but.setMaxHeight(150);
			but.setMaxWidth(150);
			String [] Imagelist=detail[4].split("/");
			con.setResult("Load Image"+":"+Imagelist[Imagelist.length-1]);
			String imagepath=downloadImage(Imagelist[Imagelist.length-1]);
			con=con.getConnection();
			detail[4]=imagepath;
			Bitmap bitmap = BitmapFactory.decodeFile(detail[4]);  
	        but.setImageBitmap(bitmap);					
	        TextView loadtv = new TextView(this);
	        loadtv.setText("Uploader : "+detail[0]);
	        TextView locationtv= new TextView(this);
	        String getloc[]=detail[1].split(",");
	        
	        locationtv.setText("Place   :      "+getloc[1]);
	        String arr[]=detail[5].split("/");
	        filename=arr[4];
	        
	        final TextView commenttv= new TextView(this);
	        commenttv.setText("Recommended : "+detail[6]);
	        
	        final ImageButton combut = new ImageButton(this) ;  
	        combut.setImageResource(R.drawable.rem);
	        
	        combut.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					String [] downvoicename=detail[4].split("/");
					String downloadname=downvoicename[downvoicename.length-1];	
					con.setResult("Comment"+":"+downloadname);
					String comment=con.getResult();
					Toast.makeText(getApplicationContext(), " recommend number is "+comment, 10000);
					detail[6]=comment.trim();
					commenttv.setText("Recommended : "+detail[6]);
					
				}
	        	
	        });
	       
	        
			but.setOnClickListener(new OnClickListener(){
               
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Log.i("method exected:", "yessssssssssssssssss");
					SelectedImage=detail[4];
					
//					String iname[]=detail[4].split("/");
//					
//					for(int z=0;z<click.length;z++)
//					{
//						if(iname[iname.length-1].equals(click[z]))
//						{
//							Selectindex=z;
//						}
//					}
					
					String ar[]=detail[5].split("/");
					String [] downvoicename=detail[3].split("/");
					String downloadname=downvoicename[downvoicename.length-1];
				    String []NAMES=downloadname.replace(".", "~").split("~");			
				   // Toast.makeText(getApplicationContext(),"download name is:"+downloadname+"--Names-->"+NAMES[0] , 10000).show();
					con.setResult("Load Sound"+":"+NAMES[0]);
					//Toast.makeText(getApplicationContext(),"start....", 10000).show();
					String path=downloadSound(NAMES[0]+".mp3");	
					//Toast.makeText(getApplicationContext(),"end....", 10000).show();
				    String []getpath=path.split("/");
					SelectedVideo=getpath[getpath.length-1];
				//	Toast.makeText(getApplicationContext(),"close....", 10000).show();
					
					//Toast.makeText(getApplicationContext(), "SelectIndex="+Selectindex, 10000).show();
					
					String [] downImagename=detail[4].split("/");
					
					SelectedInfo=detail[0]+"~"+detail[1]+"~"+downImagename[downImagename.length-1]+"~"+NAMES[0]+".mp3"+"~"+detail[6]+"~"+detail[7];
					startActivity(new Intent(MainActivity.this, ItemActivity.class));
				}
				
			});
			layout.addView(but,param) ;						
			layout.addView(loadtv,param);
			layout.addView(locationtv, param);
			layout.addView(commenttv,param);
			layout.addView(combut,param);
			
		}
		

	}
	 private SimpleAdapter getMenuAdapter(String[] menuNameArray,
	            int[] imageResourceArray) {
	        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
	        for (int i = 0; i < menuNameArray.length; i++) {
	            HashMap<String, Object> map = new HashMap<String, Object>();
	            map.put("itemImage", imageResourceArray[i]);
	            map.put("itemText", menuNameArray[i]);
	            data.add(map);
	        }
	        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
	                R.layout.item_menu, new String[] { "itemImage", "itemText" },
	                new int[] { R.id.item_image, R.id.item_text });
	        return simperAdapter;
	    }

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			String sdStatus = Environment.getExternalStorageState();
			Bundle bundle = data.getExtras();
			Bitmap bitmap = (Bitmap) bundle.get("data");
			//Toast.makeText(getApplicationContext(),"show new image" , 10000).show();		
			FileOutputStream b = null;
			File file = new File("/sdcard/myphoto/");
			file.mkdirs();
			String  fileName = "/sdcard/myphoto/" +System.currentTimeMillis() + ".jpg";
			MainPhoto=fileName;
			try {
				b = new FileOutputStream(fileName);
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					b.flush();
					b.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			((ImageView) findViewById(R.id.imageView2)).setImageBitmap(bitmap);
		}
	}
	
	 public String downloadSelfImage(String filename) {
		 try {
			    long flength; 
	            byte[] size = new byte[1024];
	            File file = new File("/sdcard/UsersImage/");
				file.mkdirs();
	            File destfile = new File("/sdcard/UsersImage/" + filename+".jpg");
	            if (!destfile.exists()) {
	            	con.setResult("ok");
	            	flength=inputFromServer.readLong();
	            	Log.i("filelength value:", Long.toString(flength));
	                FileOutputStream out = new FileOutputStream(destfile);
	                int c = -1;
	                while ((c = inputFromServer.read(size)) != -1) {
	                    out.write(size,0,c);  
	                    if(destfile.length()==flength)
	                    {
	                    	Log.i("FFin Method", "in the loop");
	                    	break;
	                    }
	                }
	                
	                out.flush();
	                out.close();
	                System.out.println("the image has been saved");                
	                return "/sdcard/UsersImage/" + filename+".jpg";
	            }else{
	            	con.setResult("false");
	                return "/sdcard/UsersImage/" + filename+".jpg";
	            }

	            }  catch (Exception ex) {
	            	  System.out.println(ex.getMessage());
	                  return "error";
	        }
	    }
	 public String downloadImage(String filename) {
		 try {
	           // DataInputStream inputFromServer = new DataInputStream(con.socket.getInputStream());
			 long flength;
			 byte[] size = new byte[1024];
	            File file = new File("/sdcard/UsersImage/");
				file.mkdirs();
	            File destfile = new File("/sdcard/UsersImage/" + filename);
	            if (!destfile.exists()) {
	            	con.setResult("ok");
	            	flength=inputFromServer.readLong();
	            	Log.i("filelength value:", Long.toString(flength));
	                FileOutputStream out = new FileOutputStream(destfile);
	                long ss = 0;
	                int c = -1;
	                while ((c = inputFromServer.read(size)) != -1) {
	                    out.write(size,0,c); 
	                    if(destfile.length()==flength)
	                    {
	                    	Log.i("FFin Method", "in the loop");
	                    	break;
	                    }
	                  
	                }
	                
	                out.flush();
	                out.close();
	                System.out.println("the image has been saved");                
	                return "/sdcard/UsersImage/" + filename;
	            }else{
	            	con.setResult("false");
	                return "/sdcard/UsersImage/" + filename;
	            }

	            }  catch (Exception ex) {
	            	  System.out.println(ex.getMessage());
	                  return "error";
	        }
	    }
	 public String downloadSound(String filename) {
		 try {
			    long flength;
	            byte[] size = new byte[1024];
	            File file = new File(savesoundpath);
				file.mkdirs();
	            File destfile = new File(savesoundpath + filename);
	            if (!destfile.exists()) {
	            	con.setResult("ok");
	            	flength=inputFromServer.readLong();
	            	Log.i("filelength value:", Long.toString(flength));
	                FileOutputStream out = new FileOutputStream(destfile);
	                int c = -1;
	                while ((c = inputFromServer.read(size)) != -1) {
	                    out.write(size,0,c); 
	                    if(destfile.length()==flength)
	                    {
	                    	Log.i("FFin Method", "in the loop");
	                    	break;
	                    }
	                  
	                }
	                out.close();
	                System.out.println("the sound has been saved");
	                Log.i("FFin Method", "the sound has been saved");
	                return savesoundpath + filename;
	            }else{
	            	con.setResult("false");
	                return savesoundpath + filename;
	            }

	            }  catch (Exception ex) {
	            	  System.out.println(ex.getMessage());
	                  return "error";
	        }
	    }

}
