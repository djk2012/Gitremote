 package com.example.PhonicPhoto;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



public class PhotoActivity extends Activity {
	public ImageView iv = null;
	public ListView lv;
	public Connection con = null;
	private TextView info = null;
	private MediaRecorder mediaRecorder = null; 
	public static File recordAudioSaveFile = null;
	public static  File recordAudioSaveFileDir = null; 
	public static  String recordAudioSaveFileName = null; 
	public static SimpleAdapter recordSimpleAdapter = null; 
	private ListView reclist = null; 
	public Map<?, ?> map = null;
	private String recDir = "Soundd"; 
	Map<String, Object> fileInfo = null;
	private boolean sdcardExists = false; 
	private boolean isRecord = false; 
	private List<Map<String, Object>> recordFiles = null; 
	public static String ImageSourcepath = null;
	public static String Imagename = null;
	public static String VoiceSourcepath = null;
	public static String Voicename = null;
	public static String Positions = "";
	public TextView locationtv = null;
	private LocationManager locationManager = null;
	public ImageView taginfo=null;
	public static String imagetag=null;
	public Spinner spinner;
	public ImageView lociv=null;
	public static boolean ChoseExists=false;
	private static int RESULT_LOAD_IMAGE = 1;
	public ArrayAdapter<String> adapter;  
    private static final String[] Tags={"nature","human","building","food","animal"};  
    public GridView gridview=null;
    public File audioFile=null;
    public boolean Record=false;
    public String [] menuchoice=new String[]{"Take Photo","Take Record","Upload","Go Back"};
    public int [] menuimages=new int []{android.R.drawable.ic_menu_camera,android.R.drawable.ic_btn_speak_now,android.R.drawable.ic_menu_upload_you_tube,R.drawable.menu_return};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.photovoice);
		
		LinearLayout layout = (LinearLayout) super.findViewById(R.id.photodownlayout) ;
		
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.MATCH_PARENT);
		
		this.iv = (ImageView) this.findViewById(R.id.photoimageView1);
		lociv=(ImageView) this.findViewById(R.id.photolocimageView1);
		this.info = (TextView) super.findViewById(R.id.Voiceinfo);
		this.taginfo=(ImageView) this.findViewById(R.id.photolocimageViewtag);
		this.spinner=(Spinner) this.findViewById(R.id.phototagspinner);
		  
		this.reclist = (ListView) super.findViewById(R.id.photorecordlist);
		this.locationtv = (TextView) this.findViewById(R.id.photoLocationtv);
		this.locationManager = (LocationManager) super
				.getSystemService(Context.LOCATION_SERVICE);
		this.locationManager.requestLocationUpdates(
				LocationManager.GPS_PROVIDER, 
				1000, 
				100, 
				new LocationListenerImpl());
		imagetag=Tags[0];
		adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,Tags);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		spinner.setAdapter(adapter);  
		
		
		   spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener()  
		           {  
		     
		               @Override  
		              public void onItemSelected(AdapterView<?> arg0, View arg1,  
		                      int arg2, long arg3) {  
		                  // TODO Auto-generated method stub  
		            	   //taginfo.setText(Tags[arg2]);  
		            	   imagetag=Tags[arg2];
		                   arg0.setVisibility(View.VISIBLE);  
		               }  
		    
		             @Override  
		               public void onNothingSelected(AdapterView<?> arg0) {  
		                   // TODO Auto-generated method stub  
		                    
		              }  
		                
		          }); 

		if (this.sdcardExists = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) { 
			this.recordAudioSaveFileDir = new File(Environment
					.getExternalStorageDirectory().toString()
					+ File.separator
					+ PhotoActivity.this.recDir + File.separator); 
			if (!this.recordAudioSaveFileDir.exists()) { 
				this.recordAudioSaveFileDir.mkdirs(); 
			}
		}
		
		this.reclist.setOnItemClickListener(new OnItemClickListenerImpl());		
		gridview=new GridView(this);
		gridview.setNumColumns(2);
		//gridview.setBackgroundColor(Color.GRAY);
		gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
		gridview.setOnItemClickListener(new OnItemClickListener(){
	    
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arg2==0)
				{
					AlertDialog.Builder dialog=new AlertDialog.Builder(PhotoActivity.this); 
				    dialog.setTitle("Chose").setIcon(android.R.drawable.ic_dialog_info).setMessage("Do you want to chose Local or take photo?")
				    .setPositiveButton("Chose Local", new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							ChoseExists=true;
							Intent i = new Intent(
									Intent.ACTION_PICK,
							android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);				
							
							startActivityForResult(i, RESULT_LOAD_IMAGE);
							
						}
						}).setNegativeButton("Take new Photo", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								ChoseExists=false;
								Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
								startActivityForResult(intent, 1);
							}
						}).create().show();
					
				}else if(arg2==1)
				{
					if (PhotoActivity.this.sdcardExists) { 
						
						if(PhotoActivity.this.isRecord==false)
						{	
						PhotoActivity.this.recordAudioSaveFileName = PhotoActivity.this.recordAudioSaveFileDir
								.toString()
								+ File.separator
								+ System.currentTimeMillis() + ".mp3"; 
						VoiceSourcepath = PhotoActivity.this.recordAudioSaveFileName;
						PhotoActivity.this.recordAudioSaveFile = new File(
								PhotoActivity.this.recordAudioSaveFileName); 
						String[] getVoicename = VoiceSourcepath.split("/");
						Voicename = getVoicename[getVoicename.length - 1];
	
						PhotoActivity.this.mediaRecorder = new MediaRecorder(); 
						PhotoActivity.this.mediaRecorder
								.setAudioSource(MediaRecorder.AudioSource.MIC); 
						PhotoActivity.this.mediaRecorder
								.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT); 
						PhotoActivity.this.mediaRecorder
								.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT); 
						PhotoActivity.this.mediaRecorder
								.setOutputFile(PhotoActivity.this.recordAudioSaveFileName); 
						try {
							PhotoActivity.this.mediaRecorder.prepare();
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						
						PhotoActivity.this.mediaRecorder.start(); 
						//PhotoActivity.this.info.setText("Recording........"); 
						PhotoActivity.this.isRecord = true; 
					
						
					}
					else if(PhotoActivity.this.isRecord==true){
						
						PhotoActivity.this.mediaRecorder.stop(); 
						PhotoActivity.this.mediaRecorder.release(); 
						//PhotoActivity.this.info.setText("Record is Stoped"); 
						PhotoActivity.this.isRecord=false;
						PhotoActivity.this.getRecordFiles(); //
					}
				
			      } 
				}else if(arg2==2)
			{
			   if(VoiceSourcepath!=null &&ImageSourcepath!=null)
			   {
				con = Connection.getConnection();
				con.setResult("Upload:" + LoginActivity.LOGINNAME + ":"
						+ Positions + ":" + Imagename + ":" + Voicename + ":"
						+ ImageSourcepath + ":" + VoiceSourcepath+":"+PhotoActivity.imagetag);
				con.getResult();
				String mess = uploadVideo(VoiceSourcepath);
				try {
					con.closeSocket();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   }else{
				   Toast.makeText(getApplication(), "Both  photo and  sound should be taken,please try again",10000).show();
			   }
				
			}
			else if(arg2==3)
			{
				startActivity(new Intent(PhotoActivity.this, MainActivity.class));
			}
//			else if(arg2==4)
//			{
//				Intent i = new Intent(
//						Intent.ACTION_PICK,
//				android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);				
//				ChoseExists=true;
//				startActivityForResult(i, RESULT_LOAD_IMAGE);
//			}
			
			
			}
			   
		   });
		layout.addView(gridview,param);
	
//	try {
//		//Positions="Nygatan 28148,Hässleholm,Sweden";
		try {
//			String [] arr = getGeographyLocation(56.1575655197085,13.7654165197085).toString().split(",");
//			arr[0]="Nytnrra Station 28148";
//			arr[1]="Hassleholm";
//			
			
			
			this.locationtv.setText("Nygatan 28148,Hassleholm,Sweden");
			Positions="Nygatan 28148,Hassleholm,Sweden";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	}
	private SimpleAdapter getMenuAdapter(String[] menuNameArray,
            int[] imageResourceArray) {
        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < menuNameArray.length; i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("itemImage", imageResourceArray[i]);
            map.put("itemText", menuNameArray[i]);
            data.add(map);
        }
        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
                R.layout.item_menu, new String[] { "itemImage", "itemText" },
                new int[] { R.id.item_image, R.id.item_text });
        return simperAdapter;
    }
	public String uploadVideo(String videopath) {
		DataOutputStream out;
		try {
			out = new DataOutputStream(Connection.socket.getOutputStream());
			byte[] size = new byte[1024];
			File destfile = new File(videopath);

			if (destfile.exists()) {
				FileInputStream ins = new FileInputStream(destfile);
				int c = -1;
				long ss = 0;
				while ((c = ins.read(size)) != -1) {
					out.write(size, 0, c);
					ss = ss + c;
				}
				ins.close();
				out.close();
				// con.closeSocket();
				System.out.println("the Video is :" + ss);
				Toast.makeText(getApplicationContext(), "The file is" + ss,
						10000).show();
				return "successfully upload";
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return "error";
	}

	public static String uploadImage(String imagepath) {
		DataOutputStream out;
		try {
			out = new DataOutputStream(Connection.socket.getOutputStream());
			byte[] size = new byte[1024];
			File destfile = new File(imagepath);

			if (destfile.exists()) {
				FileInputStream ins = new FileInputStream(destfile);

				long ss = 0;
				int c = -1;
				while ((c = ins.read(size)) != -1) {
					out.write(size, 0, c);
					ss = ss + c;

				}
				ins.close();
				out.close();
				return "successfully upload";

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return "error";
	}

	private void getRecordFiles() { 
		this.recordFiles = new ArrayList<Map<String, Object>>(); 
		System.out.println(this.recordAudioSaveFileDir.listFiles().length);
		if (this.sdcardExists) { 
			File files[] = this.recordAudioSaveFileDir.listFiles();
			 //for (int x = 0; x < files.length; x++) {
			fileInfo = new HashMap<String, Object>();
			fileInfo.put("filename", files[files.length-1].getName());
			Toast.makeText(getApplicationContext(),
					files[files.length-1].getName(), 10000).show();

			
			this.recordFiles.add(fileInfo); 
			// }
			this.recordSimpleAdapter = new SimpleAdapter(this,
					this.recordFiles, R.layout.recordfiles,
					new String[] { "filename" }, new int[] { R.id.filename }); 
			this.reclist.setAdapter(this.recordSimpleAdapter);
		}
	}

	
	private class OnItemClickListenerImpl implements OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> adapter, View view,
				int position, long id) { 
			if (PhotoActivity.this.recordSimpleAdapter.getItem(position) instanceof Map) {
				map = (Map<?, ?>) PhotoActivity.this.recordSimpleAdapter
						.getItem(position);
				Uri uri = Uri.fromFile(new File(
						PhotoActivity.this.recordAudioSaveFileDir.toString()
								+ File.separator + map.get("filename"))); 
//				Intent intent = new Intent(Intent.ACTION_VIEW); 
//				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
//				intent.setDataAndType(uri, "audio/mp3"); 
//				PhotoActivity.this.startActivity(intent); 
				AsyncPlayer player = new AsyncPlayer(null);
				if(Record==false)
				{
				
				player.play(PhotoActivity.this,uri, false, AudioManager.STREAM_MUSIC);
				Record=true;
				}else{
					player.stop();
					Record=false;
				}
				
//				audioFile=new File(PhotoActivity.this.recordAudioSaveFileDir.toString()
//						+ File.separator + map.get("filename"));
//				PlayTask player = new PlayTask(); 
//
//		        player.execute(); 

//				    Intent intent = new Intent();
//				    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				    intent.setAction(android.content.Intent.ACTION_VIEW);
//				    String type = getMIMEType(new File(PhotoActivity.this.recordAudioSaveFileDir.toString()
//							+ File.separator + map.get("filename").toString()));
//				    intent.setDataAndType(uri, type);
//				    startActivity(intent);

			}
		}
	}
	


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
	   if(ChoseExists==false)
	   {
		if (resultCode == Activity.RESULT_OK) {
			String sdStatus = Environment.getExternalStorageState();
			Bundle bundle = data.getExtras();
			Bitmap bitmap = (Bitmap) bundle.get("data");
			Toast.makeText(getApplicationContext(), "show new image", 10000)
					.show();
			FileOutputStream b = null;
			File file = new File("/sdcard/myphoto/");
			file.mkdirs();
			String fileName = "/sdcard/myphoto/" + System.currentTimeMillis()
					+ ".jpg";
			ImageSourcepath = fileName;

			String getpname[] = ImageSourcepath.split("/");
			Imagename = getpname[getpname.length - 1];

			try {
				b = new FileOutputStream(fileName);
				bitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					b.flush();
					b.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			((ImageView) findViewById(R.id.photoimageView1))
					.setImageBitmap(bitmap);
			con = Connection.getConnection();
			con.setResult("Upload Image" + ":" + Imagename);
			con.getResult();
			String mess = uploadImage(ImageSourcepath);
			
		//	Toast.makeText(getApplicationContext(), mess, 10000).show();

		}
	    }else if(ChoseExists==true){
		   if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };

				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();

				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);
				Toast.makeText(getApplication(), "the picture path is:"+picturePath, 10000);
				cursor.close();
				
				((ImageView) findViewById(R.id.photoimageView1)).setImageBitmap(BitmapFactory.decodeFile(picturePath));
				ChoseExists=false;
				ImageSourcepath=picturePath;
				con = Connection.getConnection();
				con.setResult("Upload Image" + ":" + Imagename);
				con.getResult();
				String mess = uploadImage(ImageSourcepath);
				
				Toast.makeText(getApplicationContext(), mess, 10000).show();
				
			
			}
		   
	   }
	}
	private class LocationListenerImpl implements LocationListener {

		@Override
		public void onLocationChanged(Location location) { 
			
			try {
				//Positions=getGeographyLocation(location.getLatitude(),location.getLongitude());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			PhotoActivity.this.locationtv.setText(Positions);
		
//			Toast.makeText(
//					getApplicationContext(),
//					"Current Location is:\n" + "longitude："
//							+ location.getLongitude() + "\n" + "latitude："
//							+ location.getLatitude() + "\n" + "accuracy："
//							+ location.getAccuracy() + "\n" + "time："
//							+ location.getTime() + "\n" + "speed："
//							+ location.getSpeed() + "\n" + "bearing："
//							+ location.getBearing(), 10000).show();
		}

		@Override
		public void onProviderDisabled(String provider) { 

		}

		@Override
		public void onProviderEnabled(String provider) { 
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) { 
		}

	}
	  public String getGeographyLocation(double latitude,double longtitude)
				throws Exception {											
			Map<String, String> allMap = new HashMap<String, String>();		
			StringBuffer buf = new StringBuffer();							
			try {
				URL url = new URL("http://maps.googleapis.com/maps/api/geocode/json?latlng="+latitude+","+longtitude+"&sensor=false");
				System.out.println(url);
				Scanner scan = new Scanner(url.openStream());				
				while (scan.hasNext()) {
					buf.append(scan.next());								
				}
				scan.close();											
			} catch (Exception e) {
				e.printStackTrace();
			}
			       JSONObject allData = new JSONObject(buf.toString()); 	
	                JSONArray arr= allData.getJSONArray("results");
	                JSONObject locobject=arr.getJSONObject(0);
	                System.out.println(locobject);
	                String address=locobject.get("formatted_address").toString();
	                return address;
	                
	             
	                
													
		}
	  class PlayTask extends AsyncTask<Void, Integer, Void>{ 
		  public  boolean isPlaying=false; 
		   private int frequence = 44100;  

		    private int channelConfig = AudioFormat.CHANNEL_CONFIGURATION_MONO; 

		    private int audioEncoding = AudioFormat.ENCODING_PCM_16BIT;

	        @Override 

	        protected Void doInBackground(Void... arg0) { 

	            

	            int bufferSize = AudioTrack.getMinBufferSize(frequence, channelConfig, audioEncoding); 

	            short[] buffer = new short[bufferSize/4]; 

	            //byte[] buffer = new byte[bufferSize]; 

	            try { 

	                //定义输入流，将音频写入到AudioTrack类中，实现播放

	                DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(audioFile))); 

	                //FileInputStream fis = new FileInputStream(audioFile); 

	                //实例AudioTrack 

	                AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, frequence, channelConfig, audioEncoding, bufferSize, AudioTrack.MODE_STREAM); 

	                //开始播放

	                track.play(); 

	                //由于AudioTrack播放的是流，所以，我们需要一边播放一边读取

	                while(dis.available()>0){ 

	                    int i = 0; 

	                    while(dis.available()>0 && i<buffer.length){ 

	                        buffer[i] = dis.readShort(); 
	                       // Toast.makeText(getApplicationContext(), buffer[i], 1000).show();

	                        i++; 

	                    } 

	                    //然后将数据写入到AudioTrack中

	                    track.write(buffer, 0, buffer.length); 

	                     

	                } 

	                 

	                //播放结束

	                track.stop(); 

	                dis.close(); 

	            } catch (Exception e) { 

	                // TODO: handle exception 

	            } 

	            return null; 

	        } 

	         

	        protected void onPostExecute(Void result){ 

//	            btnPlay.setEnabled(true); 
//
//	            btnFinish.setEnabled(false); 
//
//	            btnStart.setEnabled(true); 
//
//	            btnStop.setEnabled(false); 
	        	isPlaying=true;

	        } 

	         

	        protected void onPreExecute(){   

	             

	            //stateView.setText("正在播放"); 

//	            btnStart.setEnabled(false); 
//
//	            btnStop.setEnabled(false); 
//
//	            btnPlay.setEnabled(false); 
//
//	            btnFinish.setEnabled(true);          

	        } 

	         

	    } 


}
