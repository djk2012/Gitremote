package com.example.PhonicPhoto;
import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;



public class EventDetailActivity extends Activity {
	public TextView infotv,sbutv,butv,sdesttv,desttv,scomtv,comtv,sstatv,statv,sendtv,endtv,sdetv,detv;
	public ImageButton gbbt;	
	@Override
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		super.setContentView(R.layout.eventdetail);		
		this.sbutv=(TextView) this.findViewById(R.id.eventssname);
		this.sdesttv=(TextView) this.findViewById(R.id.eventssdest);
		this.scomtv=(TextView) this.findViewById(R.id.eventsscomment);
		this.sstatv=(TextView) this.findViewById(R.id.eventssstart);
		this.sendtv=(TextView) this.findViewById(R.id.eventssend);
		this.sdetv=(TextView) this.findViewById(R.id.eventssdetail);
		
		this.butv=(TextView) this.findViewById(R.id.eventssnametv);
		this.desttv=(TextView) this.findViewById(R.id.eventssdesttv);
		this.comtv=(TextView) this.findViewById(R.id.eventsscommenttv);
		this.statv=(TextView) this.findViewById(R.id.eventssstartimetv);
		this.endtv=(TextView) this.findViewById(R.id.eventssendtimetv);
		this.detv=(TextView) this.findViewById(R.id.eventssdetailtv);
		
		this.gbbt=(ImageButton) this.findViewById(R.id.eventssdetailgbbt);
		
		this.gbbt.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(EventDetailActivity.this, EventshowActivity.class));
			}
			
		});
		
		intialinfo();
		
	}
	
	public void intialinfo()
	{
	 
	  String getinfoss[]=EventshowActivity.EventINFO.split("~");
	  butv.setText(getinfoss[0]);
	  desttv.setText(getinfoss[1]);
	  comtv.setText(getinfoss[2]);
	  statv.setText(getinfoss[3]);
	  endtv.setText(getinfoss[4]);
	  detv.setText(getinfoss[5]);
	  
	               
	}

}
