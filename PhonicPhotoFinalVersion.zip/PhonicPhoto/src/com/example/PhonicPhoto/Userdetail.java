package com.example.PhonicPhoto;
import java.util.ArrayList;
import java.util.HashMap;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Userdetail extends Activity {
	public TextView snametv,nametv,spasstv,semailtv,stagtv,sfavtv;
	public EditText passet,emailet,taget,favet;
	public ImageView iv;
	public GridView gridview=null;
	public Connection con=null;
	public String [] menuchoice=new String[]{"Save","Go Back"};
    public int [] menuimages=new int []{R.drawable.menu_save,R.drawable.menu_return};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail);
		
		LinearLayout downlayout = (LinearLayout) super.findViewById(R.id.detaildownlayout) ;
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		
		this.snametv=(TextView) this.findViewById(R.id.Mainlogin);
		this.nametv=(TextView) this.findViewById(R.id.Mainloginname);
		this.spasstv=(TextView) this.findViewById(R.id.Mainpassword);
		this.semailtv=(TextView) this.findViewById(R.id.Mainemail);
		this.stagtv=(TextView) this.findViewById(R.id.Mainlogintag);
		this.sfavtv=(TextView) this.findViewById(R.id.Mainloginfav);
		
		this.passet=(EditText) this.findViewById(R.id.Mainloginpasswordtv);
		this.emailet=(EditText) this.findViewById(R.id.Mainloginemailtv);
		this.taget=(EditText) this.findViewById(R.id.Mainlogintagtv);
		this.favet=(EditText) this.findViewById(R.id.Mainloginfavtv);
		

		this.iv=(ImageView) this.findViewById(R.id.Mainloginimagview);
		
		Bitmap bitmap = BitmapFactory.decodeFile(MainActivity.userphoto);
		iv.setImageBitmap(bitmap);  
		if(LoginActivity.SelftAccess==true)
		{
		this.nametv.setText(LoginActivity.detailuser[1]);
		this.passet.setText(LoginActivity.detailuser[2]);
		this.emailet.setText(LoginActivity.detailuser[3]);
		this.taget.setText(LoginActivity.detailuser[4]);
        this.favet.setText(LoginActivity.detailuser[LoginActivity.detailuser.length-1]);	
		}else{
			 con=Connection.getConnection();
			 con.setResult("Load"+":"+LoginActivity.Selfname);
			 String resp=con.getResult();
			 String arr[]=resp.split(":");
			 this.nametv.setText(arr[1]);
		     this.passet.setText(arr[2]);
			 this.emailet.setText(arr[3]);
			 this.taget.setText(arr[4]);
		     this.favet.setText(arr[arr.length-1]);	
			 
		}
		
		
        if(LoginActivity.SelftAccess==false)
        {
        	this.passet.setVisibility(-1);
    		this.emailet.setEnabled(false);
    		this.taget.setEnabled(false);
    		this.favet.setEnabled(false);
    		
        }else{
        	this.passet.setVisibility(0);
    		this.emailet.setEnabled(true);
    		this.taget.setEnabled(true);
    		this.favet.setEnabled(true);
        }
		
		
        this.gridview=new GridView(this);
        gridview.setNumColumns(2);
       // gridview.setBackgroundColor(Color.GRAY);
		gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
		gridview.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arg2==0)
				{
					if(LoginActivity.SelftAccess==false)
					{
						Toast.makeText(getApplicationContext(),"Sorry,You do not have the right to Save" , 10000).show();
					}else{
						
				 	 boolean passt=TestPassword(passet.getText().toString());
				 	 if(passt==false)
				 	 {
				 		 Toast.makeText(getApplicationContext(), "Password is not valid", 1000).show();
				 	 }else{
					 con=Connection.getConnection();
				     con.setResult("Edit Info"+":"+LoginActivity.LOGINNAME+":"+passet.getText().toString()+":"+emailet.getText().toString()+":"+taget.getText().toString()+":"+favet.getText().toString());
				     String resp=con.getResult();
				     Toast.makeText(getApplicationContext(),"show feedback"+resp , 10000).show();
				 	 }
					}
				}else if(arg2==1)
				{
					if(LoginActivity.SelftAccess==false)
					{
			    		LoginActivity.SelftAccess=true;
					}
					startActivity(new Intent(Userdetail.this, MainActivity.class));
				}
				
			}
			   
		   });
		downlayout.addView(gridview, param);
//		this.combt.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				     con=Connection.getConnection();
//				     con.setResult("Edit Info"+":"+LoginActivity.LOGINNAME+":"+passet.getText().toString()+":"+emailet.getText().toString()+":"+taget.getText().toString()+":"+favet.getText().toString());
//				     String resp=con.getResult();
//				     Toast.makeText(getApplicationContext(),"show feedback"+resp , 10000).show();
//			}});
//		
//		this.gbbt.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				startActivity(new Intent(Userdetail.this, MainActivity.class));
//			}});
		
		
	}
	 private SimpleAdapter getMenuAdapter(String[] menuNameArray,
	            int[] imageResourceArray) {
	        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
	        for (int i = 0; i < menuNameArray.length; i++) {
	            HashMap<String, Object> map = new HashMap<String, Object>();
	            map.put("itemImage", imageResourceArray[i]);
	            map.put("itemText", menuNameArray[i]);
	            data.add(map);
	        }
	        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
	                R.layout.item_menu, new String[] { "itemImage", "itemText" },
	                new int[] { R.id.item_image, R.id.item_text });
	        return simperAdapter;
	    }
	 public boolean TestPassword(String password)
		{
			if(password.length()<7)
			{
				Toast.makeText(getApplicationContext(), "Password invalid,Password length should at least 7 ", 10000).show();
				return false;
			}
			
			
			for(int i=0;i<password.length();i++)
			{
				boolean at=testalbum(password.charAt(i));
				boolean nt=testnumber(password.charAt(i));
				if(at==false&nt==false)
				{
					Toast.makeText(getApplicationContext(), "Sorry,Password must only number or uppercase english letter ", 10000).show();
					return false;
				}
			}
			
			
			
			return true;
			
		}
		public boolean testalbum(char a)
		{
			char album[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
			for(int i=0;i<album.length;i++)
			{
				if(a==album[i])
				{
					return true;
				}
				
			}
			return false;
		}
		public boolean testnumber(char n)
		{
			char number[]={'0','1','2','3','4','5','6','7','8','9'};
			
			for(int i=0;i<number.length;i++)
			{
				if(n==number[i])
				{
					return true;
				}
			}
			return false;
		}

}
