package com.example.PhonicPhoto;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;


public class EventFormActivity extends Activity {
	public EditText whereet,startet,endet,detailet,whyet;
	public ImageButton sstart,send;
	public Connection con=null;
	 private final int DATES_DIALOG = 1;  
     private final int DATEE_DIALOG = 2; 
     public GridView gridview;
     public String [] menuchoice=new String[]{"Save","Go Back","Clean","Show"};
     public int [] menuimages=new int []{R.drawable.menu_save,R.drawable.menu_return,R.drawable.menu_delete,R.drawable.menu_view};
	@Override
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		super.setContentView(R.layout.event);
		
		
        LinearLayout layout = (LinearLayout) super.findViewById(R.id.eventdownlayout) ;
		
		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.MATCH_PARENT);
		
		this.whereet=(EditText) this.findViewById(R.id.eventwhereet);
		this.whyet=(EditText) this.findViewById(R.id.eventwhyet);
		this.startet=(EditText) this.findViewById(R.id.eventstartet);
		this.endet=(EditText) this.findViewById(R.id.eventendet);
		this.detailet=(EditText) this.findViewById(R.id.eventdetailet);
		
		
		View.OnClickListener dateSBtnListener =   
	            new BtnOnClickListener(DATES_DIALOG); 
		View.OnClickListener dateEBtnListener =   
	            new BtnOnClickListener(DATEE_DIALOG);
		
		this.sstart=(ImageButton) this.findViewById(R.id.btnDate);
		this.sstart.setOnClickListener(dateSBtnListener);
		this.send=(ImageButton) this.findViewById(R.id.btnDate2);
		this.send.setOnClickListener(dateEBtnListener);
		
		gridview=new GridView(this);
		gridview.setNumColumns(2);
		//gridview.setBackgroundColor(Color.GRAY);
		gridview.setAdapter(getMenuAdapter(this.menuchoice, this.menuimages));
		gridview.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				if(arg2==0)
				{
					con=Connection.getConnection();
					con.setResult("Upload Event"+":"+LoginActivity.LOGINNAME+":"+whereet.getText().toString()+":"+whyet.getText().toString()+":"+startet.getText().toString()+":"+endet.getText().toString()+":"+detailet.getText().toString());
					String res=con.getResult();
					Toast.makeText(getApplicationContext(),res , 10000).show();	
				}else if(arg2==1)
				{
					startActivity(new Intent(EventFormActivity.this, MainActivity.class));
				}else if(arg2==2)
				{
					whereet.setText("");
					whyet.setText("");
					startet.setText("");
					endet.setText("");
					detailet.setText("");
				}else if(arg2==3)
				{
					startActivity(new Intent(EventFormActivity.this, EventshowActivity.class));
				}
				
			}
			
		});
		layout.addView(gridview,param);
//		this.conbt.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				con=Connection.getConnection();
//				con.setResult("Upload Event"+":"+LoginActivity.LOGINNAME+":"+whereet.getText().toString()+":"+whyet.getText().toString()+":"+startet.getText().toString()+":"+endet.getText().toString()+":"+detailet.getText().toString());
//				String res=con.getResult();
//				Toast.makeText(getApplicationContext(),res , 10000).show();	
//			}});
//		this.backbt.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				startActivity(new Intent(EventFormActivity.this, MainActivity.class));
//			}
//			
//		});
//		this.cleanbt.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				whereet.setText("");
//				whyet.setText("");
//				startet.setText("");
//				endet.setText("");
//				detailet.setText("");
//				
//				
//			}
//			
//		});
//		this.show.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				startActivity(new Intent(EventFormActivity.this, EventshowActivity.class));
//			}
//			
//		});
	}
	private SimpleAdapter getMenuAdapter(String[] menuNameArray,
            int[] imageResourceArray) {
        ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < menuNameArray.length; i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("itemImage", imageResourceArray[i]);
            map.put("itemText", menuNameArray[i]);
            data.add(map);
        }
        SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
                R.layout.item_menu, new String[] { "itemImage", "itemText" },
                new int[] { R.id.item_image, R.id.item_text });
        return simperAdapter;
    }
	protected Dialog onCreateDialog(int id) {  
        //������ȡ���ں�ʱ���  
        Calendar calendar = Calendar.getInstance();   
         
       Dialog dialog = null;  
       switch(id) {  
           case DATES_DIALOG:  
                DatePickerDialog.OnDateSetListener dateListener =   
                   new DatePickerDialog.OnDateSetListener() {  
                       @Override  
                        public void onDateSet(DatePicker datePicker,   
                                int year, int month, int dayOfMonth) {  
                           
                          startet.setText(year+"/"+(month+1) + "/" + dayOfMonth);
                        }  
                    };  
                dialog = new DatePickerDialog(this,  
                       dateListener,  
                        calendar.get(Calendar.YEAR),  
                        calendar.get(Calendar.MONTH),  
                        calendar.get(Calendar.DAY_OF_MONTH));  
               break;   
           case DATEE_DIALOG:  
               DatePickerDialog.OnDateSetListener dateListeners =   
                  new DatePickerDialog.OnDateSetListener() {  
                      @Override  
                       public void onDateSet(DatePicker datePicker,   
                               int year, int month, int dayOfMonth) {  
                         endet.setText(year+"/"+(month+1) + "/" + dayOfMonth);  
                       }  
                   };  
               dialog = new DatePickerDialog(this,  
                      dateListeners,  
                       calendar.get(Calendar.YEAR),  
                       calendar.get(Calendar.MONTH),  
                       calendar.get(Calendar.DAY_OF_MONTH));  
              break;   
            default:  
                break;  
       }  
        return dialog;  
    }  
	 private class BtnOnClickListener implements View.OnClickListener {  
         
	       private int dialogId = 0;   //Ĭ��Ϊ0����ʾ�Ի���  
	  
	        public BtnOnClickListener(int dialogId) {  
	            this.dialogId = dialogId;  
	       }  
	       @Override  
	        public void onClick(View view) {  
	           showDialog(dialogId);  
	        }  
	          
	    } 

}
