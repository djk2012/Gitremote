package com.example.PhonicPhoto;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends Activity {
	public TextView info=null;
	public Spinner spinner,citySpinner=null;
	public ImageButton combt,gbbt;
	public Connection con=null;
	public ArrayList<String> lists=null;
	public String filename=null;
	public ArrayAdapter<String> adapter,cityadapter;  
	public String[] Tags={"nature","human","building","food","animal"};
	public String Searchtag=null;
	public String SearchCitytag=null;
	public LinearLayout layout;
	public LinearLayout.LayoutParams param;
	DataInputStream inputFromServer=null;
	public ArrayList<String> citylist=null;
	public static String [] Citys=null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search);
		this.info=(TextView) this.findViewById(R.id.search);
		this.spinner=(Spinner) this.findViewById(R.id.searchtagspinner);
		this.citySpinner=(Spinner) this.findViewById(R.id.searchcitytagspinner);
		this.combt=(ImageButton) this.findViewById(R.id.searchcombt);
		this.gbbt=(ImageButton) this.findViewById(R.id.searchgbbt);
		
	    layout = (LinearLayout) super.findViewById(R.id.searchdownlayout) ;
	    param = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.WRAP_CONTENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
	    Searchtag=Tags[0];
	    
	    adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,Tags);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		spinner.setAdapter(adapter);  
		
		
		con=Connection.getConnection();
		try {
			inputFromServer = new DataInputStream(con.socket.getInputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		con.setResult("City Load"+":"+LoginActivity.LOGINNAME);
		citylist=new ArrayList<String>();
		String CityRes=con.getResult();
		
		if(!CityRes.equals("Empty"))
		{
		  String tempCitys[]=CityRes.split("~");
		  for(int i=0;i<tempCitys.length;i++)
		  {
			  if(i==0)
			  {
				  citylist.add(tempCitys[i]);  
			  }else{
			  boolean confirm=TestExist(tempCitys[i]);
			  if(confirm==true)
			  {
				  citylist.add(tempCitys[i]);
				 
			  }
			  Citys=new String[citylist.size()];
			  for(int z=0;z<citylist.size();z++)
			  {
				  Citys[z]=citylist.get(z);
			  }
			  SearchCitytag=Citys[0];
		  
		  
			  }
		  
		  }
		}
		//citylist.add("Hässleholm");
		
		cityadapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,Citys);
		cityadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
		citySpinner.setAdapter(cityadapter); 
		
		citySpinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				SearchCitytag=Citys[arg2];
				arg0.setVisibility(View.VISIBLE); 
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
			
			
			
			
		} );
		
		
		spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener()  
           {  
     
               @Override  
              public void onItemSelected(AdapterView<?> arg0, View arg1,  
                      int arg2, long arg3) {  
                  // TODO Auto-generated method stub  
            	   //taginfo.setText(Tags[arg2]);  
            	   Searchtag=Tags[arg2];
                   arg0.setVisibility(View.VISIBLE);  
               }  
    
             @Override  
               public void onNothingSelected(AdapterView<?> arg0) {  
                   // TODO Auto-generated method stub  
                    
              }  
                
          }); 
		
		this.combt.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				getListItem(Searchtag,SearchCitytag);
				
			}
			
		});
		this.gbbt.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(SearchActivity.this, MainActivity.class));
			}
			
		});
		
		
		
	}
	
	public void getListItem(String tagname,String cityname)
	{
		layout.removeAllViews();
		lists=new ArrayList<String>();
//		con=Connection.getConnection();
//		try {
//			inputFromServer = new DataInputStream(con.socket.getInputStream());
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		con.setResult("CityTag Load"+":"+tagname+":"+cityname);
		int count=Integer.parseInt(con.getResult().trim());
		con.setResult("continue");	
		for(int i=0;i<count;i++)
		{
	    String ss=con.getResult();
		lists.add(ss);
		//Toast.makeText(getApplicationContext(),"this is :"+ss, 10000).show();	
		}
		for (int x = 0; x < lists.size(); x++) {
			final String [] detail=lists.get(x).split("~");
			final ImageButton but = new ImageButton(this) ;	
			String [] Imagelist=detail[4].split("/");
			con.setResult("Load Image"+":"+Imagelist[Imagelist.length-1]);
			
			String imagepath=downloadImage(Imagelist[Imagelist.length-1]);
			con=con.getConnection();
			detail[4]=imagepath;
			Bitmap bitmap = BitmapFactory.decodeFile(detail[4]);  
	        but.setImageBitmap(bitmap);					
	        TextView loadtv = new TextView(this);
	        loadtv.setText("Uploader : "+detail[0]);
	        TextView locationtv= new TextView(this);
	        String getloc[]=detail[1].split(",");
	        locationtv.setText("Place   :      "+getloc[1]);
	        String arr[]=detail[5].split("/");
	        filename=arr[4];
	        
	        final TextView commenttv= new TextView(this);
	        commenttv.setText("Recommended : "+detail[6]);
	        
	        final ImageButton combut = new ImageButton(this) ;  
	        combut.setImageResource(R.drawable.rem);
	        combut.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					String [] downvoicename=detail[4].split("/");
					String downloadname=downvoicename[downvoicename.length-1];	
					con=Connection.getConnection();
					con.setResult("Comment"+":"+downloadname);
					String comment=con.getResult();
					detail[6]=comment.trim();
					commenttv.setText("Recommended : "+detail[6]);
					
				}
	        	
	        });
	       
	        
			but.setOnClickListener(new OnClickListener(){
               
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					MainActivity.SelectedImage=detail[4];
					String ar[]=detail[5].split("/");
					String [] downvoicename=detail[3].split("/");
					String downloadname=downvoicename[downvoicename.length-1];
				    String []NAMES=downloadname.replace(".", "~").split("~");			
				    Toast.makeText(getApplicationContext(),"download name is:"+downloadname+"--Names-->"+NAMES[0] , 10000).show();
					con=Connection.getConnection();
					con.setResult("Load Sound"+":"+NAMES[0]);
					Toast.makeText(getApplicationContext(),"start....", 10000).show();
					String path=downloadSound(NAMES[0]+".mp3");	
					Toast.makeText(getApplicationContext(),"end....", 10000).show();
				    String []getpath=path.split("/");
					MainActivity.SelectedVideo=getpath[getpath.length-1];
					Toast.makeText(getApplicationContext(),"close....", 10000).show();
					
					String [] downImagename=detail[4].split("/");
					MainActivity.SelectedInfo=detail[0]+"~"+detail[1]+"~"+downImagename[downImagename.length-1]+"~"+NAMES[0]+".mp3"+"~"+detail[6]+"~"+detail[7];
					startActivity(new Intent(SearchActivity.this, ItemActivity.class));
				}
				
			});
			layout.addView(but,param) ;						// 增加组件
			layout.addView(loadtv,param);
			layout.addView(locationtv, param);
			layout.addView(commenttv,param);
			layout.addView(combut,param);
			
		}
		
	}
	public  boolean TestExist(String city)
	{
		for(int i=0;i<citylist.size();i++)
		{
			if(!city.equals(citylist.get(i))){
				return true;
			}
		}
		return false;
	}
	 public String downloadImage(String filename) {
		 try {
	           // DataInputStream inputFromServer = new DataInputStream(con.socket.getInputStream());
			 long flength;
			 byte[] size = new byte[1024];
	            File file = new File("/sdcard/UsersImage/");
				file.mkdirs();
	            File destfile = new File("/sdcard/UsersImage/" + filename);
	            if (!destfile.exists()) {
	            	con.setResult("ok");
	            	flength=inputFromServer.readLong();
	            	Log.i("filelength value:", Long.toString(flength));
	                FileOutputStream out = new FileOutputStream(destfile);
	                long ss = 0;
	                int c = -1;
	                while ((c = inputFromServer.read(size)) != -1) {
	                    out.write(size,0,c); 
	                    if(destfile.length()==flength)
	                    {
	                    	Log.i("FFin Method", "in the loop");
	                    	break;
	                    }
	                  
	                }
	                
	                out.flush();
	                out.close();
	                System.out.println("the image has been saved");                
	                return "/sdcard/UsersImage/" + filename;
	            }else{
	            	con.setResult("false");
	                return "/sdcard/UsersImage/" + filename;
	            }

	            }  catch (Exception ex) {
	            	  System.out.println(ex.getMessage());
	                  return "error";
	        }
	    }
	 public String downloadSound(String filename) {
		 try {
			    long flength; 
	            byte[] size = new byte[1024];
	            File file = new File(MainActivity.savesoundpath);
				file.mkdirs();
	            File destfile = new File(MainActivity.savesoundpath + filename);
	            if (!destfile.exists()) {
	            	con.setResult("ok");
	            	flength=inputFromServer.readLong();
	                FileOutputStream out = new FileOutputStream(destfile);
	                long ss = 0;
	                int c = -1;
	                while ((c = inputFromServer.read(size)) != -1) {
	                    out.write(size,0,c); 
	                    if(destfile.length()==flength)
	                    {
	                    	Log.i("FFin Method", "in the loop");
	                    	break;
	                    }
	                }
	                out.flush();
	                out.close();
	                System.out.println("the sound has been saved");                
	                return MainActivity.savesoundpath + filename;
	            }else{
	            	con.setResult("false");
	                return MainActivity.savesoundpath + filename;
	            }

	            }  catch (Exception ex) {
	            	  System.out.println(ex.getMessage());
	                  return "error";
	        }
	    }

}
