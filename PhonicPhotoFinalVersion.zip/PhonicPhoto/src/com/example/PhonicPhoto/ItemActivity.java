package com.example.PhonicPhoto;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.degreeprojectandroid.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class ItemActivity extends Activity {
	private ListView reclist = null; 
	private SimpleAdapter recordSimpleAdapter = null;
	public Map<?, ?> map=null;
	private File recordAudioSaveFileDir = null;
	private List<Map<String, Object>> recordFiles = null;
	private boolean sdcardExists = false;
	private String recDir = "Soundd";	
	Map<String, Object> fileInfo =null;
	public ImageButton tv=null;
	public ImageButton bn=null;
	public TextView loctv,recommendtv,typttv=null;
	public ImageView iv1,iv2,iv3,iv4,iv5,iv6;
	public Button nametv;
	@Override
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		super.setContentView(R.layout.item);
		
		this.iv1=(ImageView) this.findViewById(R.id.imageView1);
		this.iv2=(ImageView) this.findViewById(R.id.imageView2);
		this.iv5=(ImageView) this.findViewById(R.id.imageView5);
		this.iv6=(ImageView) this.findViewById(R.id.imageView6);
		
		this.nametv=(Button) this.findViewById(R.id.itemuplodernametv);
		this.loctv=(TextView) this.findViewById(R.id.itemlocationtv);
		this.recommendtv=(TextView) this.findViewById(R.id.itemrecommendtv);
		this.typttv=(TextView) this.findViewById(R.id.itemtypttv);
		
		
		
//		
//		if (this.sdcardExists = Environment.getExternalStorageState().equals(
//				Environment.MEDIA_MOUNTED)) { 
//			this.recordAudioSaveFileDir = new File(Environment
//					.getExternalStorageDirectory().toString()
//					+ File.separator
//					+ ItemActivity.this.recDir + File.separator); 
//			if (!this.recordAudioSaveFileDir.exists()) { 
//				this.recordAudioSaveFileDir.mkdirs(); 
//			}
//		}
//		getRecordFiles();	
		final String info[]=MainActivity.SelectedInfo.split("~");
		nametv.setText(" "+info[0]);
		//info[1]=info[1].substring(5);
		loctv.setText("  "+info[1]);
		recommendtv.setText("  "+info[4]);
		typttv.setText("  "+info[5]);
		//selectinfotv.setText("Taker :"+info[0]+"\n"+"Position : "+info[1]+"\n"+"Image Name : "+info[2]+"\n"+"Video Name : "+info[3]+"\n"+" Comment :"+info[4]+"\n"+"Type :"+info[5]);
		tv=(ImageButton) this.findViewById(R.id.itemiv);
		Bitmap bitmap = BitmapFactory.decodeFile(MainActivity.SelectedImage);  
		
		nametv.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(LoginActivity.LOGINNAME.equals(info[0]))
				{
					startActivity(new Intent(ItemActivity.this, MainActivity.class));
				}else{
					LoginActivity.SelftAccess=false;
					LoginActivity.Selfname=info[0];
					startActivity(new Intent(ItemActivity.this, MainActivity.class));
				}
				
			}});
		
		int width = bitmap.getWidth();
	    int height = bitmap.getHeight();
	    
	    int newWidth = 480;
	    int newHeight = 280;
	    
	    float scaleWidth = ((float) newWidth) / width;
	    float scaleHeight = ((float) newHeight) / height;
	    
		Matrix matrix = new Matrix();
	    matrix.postScale(scaleWidth, scaleHeight);
	    
	    Bitmap newbitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix,
	    	      true);
	    
        tv.setImageBitmap(newbitmap);	
        tv.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub	
				
				map = (Map<?, ?>) PhotoActivity.recordSimpleAdapter
						.getItem(0);
				Uri uri = Uri.fromFile(new File(
						PhotoActivity.recordAudioSaveFileDir.toString()
								+ File.separator + map.get("filename"))); 
				AsyncPlayer player = new AsyncPlayer(null);
				player.play(ItemActivity.this,uri, false, AudioManager.STREAM_MUSIC);
				
				
				
//				Uri uri = Uri.fromFile(new File(
//						ItemActivity.this.recordAudioSaveFileDir
//								.toString()
//								+ File.separator
//								+ MainActivity.SelectedVideo));			// ���������Uri
//				Intent intent = new Intent(Intent.ACTION_VIEW);		// ָ��Action
//				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);		// ���ӱ��
//				intent.setDataAndType(uri, "audio/mp3");			// �������ݲ��ŵ�MIME
//				ItemActivity.this.startActivity(intent);		// ����Activity
//				

			}
        });
		bn=(ImageButton) this.findViewById(R.id.itemgb);
		bn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(ItemActivity.this, MainActivity.class));
			}
			
		});
		
		if (this.sdcardExists = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) { 				// �ж�SD���Ƿ����
			this.recordAudioSaveFileDir = new File(Environment
					.getExternalStorageDirectory().toString()
					+ File.separator
					+ recDir + File.separator); // ����¼��Ŀ¼
		
			if (!this.recordAudioSaveFileDir.exists()) { 	// ���ļ��в�����
				this.recordAudioSaveFileDir.mkdirs(); 		// �����µ��ļ���
			}
	}
		
	}
	private void getRecordFiles() { 
		this.recordFiles = new ArrayList<Map<String, Object>>(); 
		System.out.println(this.recordAudioSaveFileDir.listFiles().length);
		if (this.sdcardExists) { 
			File files[] = this.recordAudioSaveFileDir.listFiles();
			// for (int x = 0; x < files.length; x++) {
			fileInfo = new HashMap<String, Object>();
			fileInfo.put("filename", files[files.length - 1].getName());
			Toast.makeText(getApplicationContext(),
					files[files.length - 1].getName(), 10000).show();

			
			this.recordFiles.add(fileInfo); 
			// }
			this.recordSimpleAdapter = new SimpleAdapter(this,
					this.recordFiles, R.layout.recordfiles,
					new String[] { "filename" }, new int[] { R.id.filename }); 
			this.reclist.setAdapter(this.recordSimpleAdapter);
		}
	}
}
