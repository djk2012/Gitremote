﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace DA544BLab3
{
    public partial class FirstPage : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
  //          CREATE TABLE [dbo].[ingredients] (
 //   [ItemID]       INT          NOT NULL,
 //   [Type]         INT          NULL,
   // [Description]  VARCHAR (50) NULL,
   // [Protein]      INT          NULL,
    //[Fat]          INT          NULL,
   // [Carbohydrate] INT          NULL,
  //  PRIMARY KEY CLUSTERED ([ItemID] ASC)
//);

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int protein = Int32.Parse(this.TextBox6.Text.ToString());
            int fat = Int32.Parse(this.TextBox7.Text.ToString());
            int carb = Int32.Parse(this.TextBox8.Text.ToString());
            int sum = protein + fat + carb;
            if (sum == 100)
            {


                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
                conn.Open();
                int ID = Int32.Parse(this.TextBox1.Text.ToString());
                String sql = "insert into ingredients values(" + ID + ",1,'sfs',20,30,50)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                conn.Close();


                showdescription(ID);
            }
            else
            {
                Response.Write("protein,fat,car value sum is not 100!!");
            }


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
            conn.Open();
            int ID = Int32.Parse(this.TextBox1.Text.ToString());
            String sql = "update ingredients set Protein="+ID+"where ItemID="+ID+"";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            conn.Close();
           
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
            conn.Open();
            int ID = Int32.Parse(this.TextBox1.Text.ToString());
            String sql = "delete from ingredients where ItemID="+ID+"";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            conn.Close();
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        public void showdescription(int id)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
            conn.Open();

            String sql = "select * from ingredients where ItemID=" + id + "";
            SqlDataAdapter adpt = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            adpt.Fill(dt);

            this.GridView1.DataSource = dt;
            this.GridView1.DataBind();
        }
    }
}