﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace DA544BLab3
{
    public partial class SecondPage : System.Web.UI.Page
    {
        static List<String> al = new List<string>();
        protected void Page_Load(object sender, EventArgs e)
        {
   //         CREATE TABLE [dbo].[productschedule] (
 //   [ProductNo]    INT          NOT NULL,
  //  [RMdescrition] VARCHAR (50) NULL,
 //   [Weight]       INT          NULL,
 //   [Protein]      FLOAT (53)   NULL,
 //   [Fat]          FLOAT (53)   NULL,
  //  [Carbohydrate] FLOAT (53)   NULL,
  //  PRIMARY KEY CLUSTERED ([ProductNo] ASC)
//);


        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
     
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("aaaaaaaaaaaaaaaaaaaaaaaaaaa111111aaaaaaaaaaaaaaa");
            int productno = 0;
            String description = null;
            int weight = Int32.Parse(this.TextBox2.Text.ToString());
                
            float protein = 0;
            float fat = 0;
            float car = 0;
           
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
                conn.Open();

                String sql = "select ItemID,Type,Description,Protein,Fat,Carbohydrate from ingredients ";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader data = cmd.ExecuteReader();
              
                while (data.Read())
                {

                    productno = Int32.Parse(data.GetValue(0).ToString());
                    description = data.GetValue(2).ToString();
                    protein=float.Parse(data.GetValue(3).ToString());
                    fat = float.Parse(data.GetValue(4).ToString());
                    car = float.Parse(data.GetValue(5).ToString());                 
                    this.Label1.Text = data.GetValue(2).ToString();
                }
                
                 
                data.Close();
                conn.Close();
                
          //  }
                Response.Write("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
                insertcumserinfo(productno, description, weight, protein, fat, car);
                showresult();
               
                   String aaa =protein+fat+car+"";
                   this.Label1.Text = aaa;


           
        }
        public void insertcumserinfo(int product,String des,int wei,float protein,float fat,float car)
        {

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
            conn.Open();
            int ID = Int32.Parse(this.TextBox3.Text.ToString());
            String sql = "insert into productschedule values("+ID+",'" + des + "'," + wei + "," + protein + "," + fat + "," + car + ")";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            conn.Close();
        }
        public void showresult()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
            conn.Open();

            String sql = "select * from productschedule ";
            SqlDataAdapter adpt = new SqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            this.GridView1.DataSource = dt;
            this.GridView1.DataBind();



        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.DropDownList1.Items.Clear();
            if (this.RadioButtonList1.SelectedItem.Text.Equals("animal"))
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
                conn.Open();

                String sql = "select ItemID,Type,Description,Protein,Fat,Carbohydrate from ingredients  where Type=0";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader data = cmd.ExecuteReader();
                while (data.Read())
                {
                    al.Add(data.GetValue(2).ToString());
                    this.DropDownList1.Items.Add(data.GetValue(2).ToString());
                    this.Label1.Text = data.GetValue(2).ToString();
                }
                data.Close();
                conn.Close();
               

                    
               

            }
            else if (this.RadioButtonList1.SelectedItem.Text.Equals("plant"))
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Data Source=(localdb)\Projects; Initial Catalog=Account";
                conn.Open();

                String sql = "select ItemID,Type,Description,Protein,Fat,Carbohydrate from ingredients  where Type=1";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader data = cmd.ExecuteReader();
                while (data.Read())
                {
                    al.Add(data.GetValue(2).ToString());
                    this.DropDownList1.Items.Add(data.GetValue(2).ToString());
                    this.Label1.Text = data.GetValue(2).ToString();
                }
                data.Close();
                conn.Close();

            }
        }

       
    }
}