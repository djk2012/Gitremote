package ding1.jun;






import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class TestLabActivity extends Activity {
    /** Called when the activity is first created. */
	Data dd = new Data(this);
	//public static ArrayList<Date> infolist =new ArrayList<Date>();
	public static String udata =null;
	public static String uexpense=null;
	public static String ucategory=null;
	public static String usum=null;
 	public static String utype=null;
	//public Date userinfo;
 	private Spinner categoryInf;
	//public Date menuinfo;
	private Button mainreg=null;
	private Button mainlist=null;
	private Button mainbud=null;
	private Button mainsa=null;
	private Button maincle=null;
	private Button maingra=null;
	
	
	
	
	public EditText datainfo =null;
	public EditText expenseinfo=null;
	public EditText suminfo=null;
	
	public String col[];
	DatabaseHelper mOpenHelper;

//	private static final String DATABASE_NAME = "ListInfo.db";
	private static final int DATABASE_VERSION = 1;
//	private static final String TABLE_NAME = "Info";
//	private static final String DATE = "   Date  ";
//	private static final String  EXPENSE = "Expense";
//	private static final String  CATEGORY = "Category";
//	private static final String TYPE="Type";
//	private static final String SUM=" Sum  ";
	
	
	
	public static final String DATABASE_NAME = "dbForTest.db";
	public static final String TABLE_NAME = "diary";
	public static final String DATE = "Date";
	public static final String EXPENSE = "Expense";
	public static final String CATEGORY = "Category";
	public static final String TYPE = "Type";
	public static final String SUM = "Sum";
	
	
	public  RadioButton visabutton=null;
	public  RadioButton cashbutton=null;
	


	
	public static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {

//			String sql = "CREATE TABLE " + TABLE_NAME + " (" + DATE
//					+ " text not null, " + EXPENSE + " text not null "+CATEGORY+ " text not null "+ TYPE+ " text not null "+SUM+ " text not null "+ ");";
//			
//			db.execSQL(sql);
        
			
			String sql = "CREATE TABLE " + TABLE_NAME + " (" + DATE
					+ " text not null, " + EXPENSE + " text not null ," +  CATEGORY  + " text not null, "+  TYPE  + " text not null, "+ SUM + " text not null " + ");";
			Log.i("createDB=", sql);
			db.execSQL(sql);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			
		}

		
	}
	
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
         mOpenHelper = new DatabaseHelper(this);
 
//        String date="  Date    ";
//        String expense="    Expense   ";
//        String category="    Category  ";
//        String type="   Type    ";
//        String sum="   Sum      ";
//        menuinfo= new ListContent(date,expense,category,type,sum);
//        infolist.add(0, menuinfo);
        
        
        this.mainbud=(Button)this.findViewById(R.id.mainbudge);
        this.mainlist=(Button)this.findViewById(R.id.mainlist);
        this.mainsa=(Button)this.findViewById(R.id.save);
        this.maincle=(Button)this.findViewById(R.id.clear);
        this.maingra=(Button)this.findViewById(R.id.maingrapic);
        
        
        this.datainfo=(EditText)this.findViewById(R.id.et1);
        this.expenseinfo=(EditText)this.findViewById(R.id.et2);
        this.suminfo=(EditText)this.findViewById(R.id.et3);
        
        
        
        categoryInf = (Spinner) findViewById(R.id.sp1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.Choice, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoryInf.setAdapter(adapter);
        categoryInf.setPrompt("Choice");
        
        this.visabutton=(RadioButton)this.findViewById(R.id.rb1);
        this.cashbutton=(RadioButton)this.findViewById(R.id.rb2);
        
        
//        this.maingra.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				Intent intent = new Intent();
//				 //intent.setClass(TestLabActivity.this, BudgetInterface.class);
//				// TestLabActivity.this.startActivity(intent);
//				intent.setClass(TestLabActivity.this, GraphActivity.class);
//				TestLabActivity.this.startActivity(intent);
//				 
//			}});

        
        
        
        this.mainsa.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				CreateTable();
				udata=datainfo.getText().toString();
				uexpense=expenseinfo.getText().toString();
				ucategory=categoryInf.getSelectedItem().toString();
				
				usum=suminfo.getText().toString();
				
				dd.open();
				dd.addData(udata, uexpense, ucategory, utype,usum);
				dd.close();
				//insertItem();
				
//				String uexp =expenseinfo.getText().toString();
//				String usum=suminfo.getText().toString();
//				String food="food";
//				String visa="visa";
//				
//				userinfo = new ListContent(udata,uexp,food,visa,usum);
//				TestLabActivity.this.infolist.add(userinfo);
//				Toast.makeText(TestLabActivity.this, "��Ϣʱ"+userinfo.toString(),Toast.LENGTH_LONG);
				//System.out.println("ssssss"+udata);
			}
        	
        	
        	
        });
        
        
        
        this.visabutton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				utype=" Visa";
			}
        	
        	
        });
        	
        	
        	
       
        this.cashbutton.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				utype=" Cash";
			}
        	
        	
        	
        });
        
        
        this.mainbud.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				 intent.setClass(TestLabActivity.this, BudgetInterface.class);
				 TestLabActivity.this.startActivity(intent);
				//intent.setClass(TestLabActivity.this, GraphActivity.class);
				 //TestLabActivity.this.startActivity(intent);
				 
			}});

			
        
        
        
        
        this.mainlist.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				 intent.setClass(TestLabActivity.this, ListInterface.class);
				 TestLabActivity.this.startActivity(intent);
				
			}
        	
        });
        
        this.maincle.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				datainfo.setText("");
				expenseinfo.setText("");
				suminfo.setText("");
			}
        	
        	
        });
        
        this.maingra.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				 intent.setClass(TestLabActivity.this, GraphActivity.class);
				 TestLabActivity.this.startActivity(intent);
				
			}
        	
        });
    }
    
    
    
    
    private void CreateTable() {
//		       SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//	           String sql = "CREATE TABLE " + TABLE_NAME + " (" + DATE
//				+ " text not null, " + EXPENSE + " text not null "+CATEGORY+ " text not null "+ TYPE+ " text not null "+SUM+ " text not null "+ ");";
//		
//
//		try {
//			db.execSQL("DROP TABLE IF EXISTS Info");
//			db.execSQL(sql);
//			setTitle(" The table has been successfully created");
//		} catch (SQLException e) {
//			setTitle("creating error");
//		}
    	
    	
    	
//    	SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//		String sql = "CREATE TABLE " + TABLE_NAME + " (" + DATE
//				+ " text not null, " + EXPENSE + " text not null," + CATEGORY + " text not null, " + TYPE + " text not null, "+ SUM + " text not null "+");";
//		Log.i("createDB=", sql);
//
//		try {
//			db.execSQL("DROP TABLE IF EXISTS diary");
//			db.execSQL(sql);
//			setTitle("reconstruct successfully");
//		} catch (SQLException e) {
//			setTitle("reconstruct failed");
//		}

	}

	
	private void dropTable() {
//		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//		String sql = "drop table " + TABLE_NAME;
//		try {
//			db.execSQL(sql);
//			setTitle("success to delete��" + sql);
//		} catch (SQLException e) {
//			setTitle("delete error!");
//		}
//		
		
		
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		String sql = "drop table " + TABLE_NAME;
		try {
			db.execSQL(sql);
			setTitle("delete successed��" + sql);
		} catch (SQLException e) {
			setTitle("delelte failed");
		}

	}

	
	private void insertItem() {
//		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
//		String sql1 = "insert into " + TABLE_NAME + " (" + DATE + ", " + EXPENSE+ ", "+CATEGORY+ ", "+TYPE+ ", "+SUM
//				+ ") values('2012/3/8', 'Lunch','Food','Visa','200');";
////		String sql2 = "insert into " + TABLE_NAME + " (" + DATE + ", " + EXPENSE+ ", "+CATEGORY+ ", "+TYPE+ ", "+SUM
////				+ ") values('2012/3/9', 'Supper','Food','Cash','100');";
//		try {
//			//Log.i("sql1=", sql1);
//		
//			db.execSQL(sql1);
//			//db.execSQL(sql2);
//			setTitle("insert successful");
//		} catch (SQLException e) {
//			setTitle("insert failed");
//		}
//		
		
		
		SQLiteDatabase db = mOpenHelper.getWritableDatabase();
		String sql1 = "insert into " + TABLE_NAME + " (" + DATE + ", " + EXPENSE + "," + CATEGORY + " , "+ TYPE + " , "+  SUM 
				+ ") values('"+udata+"', '"+uexpense+"','"+ucategory+"','"+utype+"','"+usum+"');";
//		String sql2 = "insert into " + TABLE_NAME + " (" + DATE + ", " + EXPENSE+ ", " + CATEGORY + " , "+ TYPE + " , "+  SUM  
//				+ ") values('2012/3/9', 'Supper','Clothes','Cash','400');";
		try {
			Log.i("sql1=", sql1);
			//Log.i("sql2=", sql2);
			db.execSQL(sql1);
			//db.execSQL(sql2);
			setTitle("insert successful");
		} catch (SQLException e) {
			setTitle("insert failed");
		}

	}

	
	private void deleteItem() {
		try {
			SQLiteDatabase db = mOpenHelper.getWritableDatabase();
			db.delete(TABLE_NAME, " Date = '2012/3/8'", null);
			setTitle("delet the Date=2012/3/8");
		} catch (SQLException e) {

		}



	}

	
	public void showItems() {

//		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
//		String col[] = { DATE, EXPENSE,CATEGORY,TYPE,SUM};
//		Cursor cur = db.query(TABLE_NAME, col, null, null, null, null, null);
//		Integer num = cur.getCount();
//		while(cur.moveToNext())
//		{
//			String name =cur.getString(cur.getColumnIndex("Date"));
//			System.out.println("��Ϣʱ"+name);
//		}
//		  
//		  
//		setTitle(Integer.toString(num) + " informations");
		
		
		

		SQLiteDatabase db = mOpenHelper.getReadableDatabase();
	    col = new String[]{ DATE, EXPENSE,CATEGORY,TYPE,SUM };
		Cursor cur = db.query(TABLE_NAME, col, null, null, null, null, null);
		Integer num = cur.getCount();
	
		
//		while(cur.moveToNext())
//		{
//			 Date= cur.getString(cur.getColumnIndex("Date"));
//			 Expense=cur.getString(cur.getColumnIndex("Expense"));
//		}
//		setTitle(Integer.toString(num) + Date+Expense+" numbers information");

	}

   
    
}