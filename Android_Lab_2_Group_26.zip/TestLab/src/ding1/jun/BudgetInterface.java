package ding1.jun;




import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class BudgetInterface extends Activity {
	
	private Button budreg =null;
	private Button budlist =null;
	private Button budgra = null;
	Data data = new Data(this);
	
	
	private ProgressBar progressBar1, progressBar2, progressBar3, progressBar4;	
	private TextView txt1, txt2, txt3, txt4;
	public static int count1, count2, count3, count4;
	
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.budget);
	        
	        
	        this.budreg=(Button)this.findViewById(R.id.budgetregister);
	        this.budlist=(Button)this.findViewById(R.id.budgetlist);
	        this.budgra=(Button)this.findViewById(R.id.budgetrapic);
	        
	        txt1 = (TextView) findViewById(R.id.tv2);
			txt2 = (TextView) findViewById(R.id.tv4);
			txt3 = (TextView) findViewById(R.id.tv6);
			txt4 = (TextView) findViewById(R.id.tv8);
			
			progressBar1 = (ProgressBar) findViewById(R.id.pb2);
			progressBar2 = (ProgressBar) findViewById(R.id.pb3);
			progressBar3 = (ProgressBar) findViewById(R.id.pb4);
			progressBar4 = (ProgressBar) findViewById(R.id.pb5);
	        
			data.open();
			
			
     		Cursor c1 = Data.db.query("diary", null, "Category=?",
				new String[] { "Food" }, null, null, null);
			int sumIndex1 = c1.getColumnIndex("Sum");
			for (c1.moveToFirst(); !c1.isAfterLast(); c1.moveToNext()) {
				count1 += Integer.parseInt(c1.getString(sumIndex1));
			}
			progressBar1.setMax(1000);
		    progressBar1.setProgress(count1);
		    txt1.setText(count1+"kr");
		    
		    
		    Cursor c2 = Data.db.query("diary", null, "Category=?",
					new String[] { "Transportation" }, null, null, null);
			int sumIndex2 = c2.getColumnIndex("Sum");
			for(c2.moveToFirst();!c2.isAfterLast(); c2.moveToNext()){
				count2+=Integer.parseInt(c2.getString(sumIndex2));
			}
			progressBar2.setMax(1000);
			progressBar2.setProgress(count2);
			txt2.setText(count2+"kr");
	        
			
			Cursor c3 = Data.db.query("diary", null, "Category=?",
					new String[] { "Clothes" }, null, null, null);
			int sumIndex3 = c2.getColumnIndex("Sum");
			for(c3.moveToFirst();!c3.isAfterLast(); c3.moveToNext()){
				count3+=Integer.parseInt(c3.getString(sumIndex3));
			}
			progressBar3.setMax(1000);
			progressBar3.setProgress(count3);
			txt3.setText(count3+"kr");
			
			Cursor c4 = Data.db.query("diary", null, "Category=?",
					new String[] { "Hobby" }, null, null, null);
			int sumIndex4 = c2.getColumnIndex("Sum");
			for(c4.moveToFirst();!c4.isAfterLast(); c4.moveToNext()){
				count4+=Integer.parseInt(c4.getString(sumIndex4));
			}
			progressBar4.setMax(1000);
			progressBar4.setProgress(count4);
			txt4.setText(count4+"kr");
			
	        this.budreg.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					 Intent intent = new Intent();
					 intent.setClass(BudgetInterface.this, TestLabActivity.class);
					 BudgetInterface.this.startActivity(intent);
				}
	        	
	        });
	        
	        
	        this.budlist.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					 Intent intent = new Intent();
					 intent.setClass(BudgetInterface.this, ListInterface.class);
					 BudgetInterface.this.startActivity(intent);
				}
	        	
	        });
	        
	        
	        this.budgra.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					 Intent intent = new Intent();
					 intent.setClass(BudgetInterface.this, GraphActivity.class);
					 BudgetInterface.this.startActivity(intent);
				}
	        	
	        });
	        
	        
	    }
	 
	 
	 
}
