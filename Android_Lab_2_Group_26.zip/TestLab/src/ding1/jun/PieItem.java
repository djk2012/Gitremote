package ding1.jun;

public class PieItem {

	public int count, color;
	public float percent;
	public String label;

	
}
