package ding1.jun;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Data {
	public DBHelper help;
	public static SQLiteDatabase db;
	public Context c;
	
	public Data(Context c){
		this.c =c;	
	}
	
	public Data open(){
		help=new DBHelper(c);
		db=help.getWritableDatabase();
		return this;
	}
		
	public void close(){
		help.close();
	}
	
	public void addData( String date, String expense, String category,String type, String sum){
		ContentValues values=new ContentValues ();
		values.put("Date", date);
		values.put("Expense", expense);
		values.put("Category", category);
		values.put("Type", type);	
		values.put("Sum", sum);
		db.insert("diary", null, values);
	}
}
