package ding1.jun;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class GraphActivity extends Activity{ 
    
	List<PieItem> piedata = new ArrayList<PieItem>(0);
	
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.graph);
        
        PieItem item;
		int maxCount = 0;
		int itemCount = 0;
		int items[] = { BudgetInterface.count1, BudgetInterface.count2+10, BudgetInterface.count3+30, BudgetInterface.count4 };
		int colors[] = { -6777216, -16776961, -16711681, -12303292 };
		for (int i = 0; i < items.length; i++) {
			itemCount = items[i];
			item = new PieItem();
			item.count = itemCount;
			item.color = colors[i];
			piedata.add(item);
			maxCount = maxCount + itemCount;
		}
		int size = 155;
		int BgColor = 0xffa11b1;
		Bitmap mBaggroundImage = Bitmap.createBitmap(size, size,
				Bitmap.Config.ARGB_8888);
		PieChart piechart = new PieChart(this);
		piechart.setLayoutParams(new LayoutParams(size, size));
		piechart.setGeometry(size, size, 2, 2, 2, 2, 2130837504);
		piechart.setSkinparams(BgColor);
		piechart.setData(piedata, maxCount);
		piechart.invalidate();
		piechart.draw(new Canvas(mBaggroundImage));
		piechart = null;
		ImageView mImageView = new ImageView(this);
		mImageView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));
		mImageView.setBackgroundColor(BgColor);
		mImageView.setImageBitmap(mBaggroundImage);
		LinearLayout finalLayout = (LinearLayout) findViewById(R.id.pie_container);
		finalLayout.addView(mImageView);
        
    }
    
    
    
}