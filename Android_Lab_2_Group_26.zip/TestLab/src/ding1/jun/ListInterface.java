package ding1.jun;





import ding1.jun.TestLabActivity.DatabaseHelper;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class ListInterface extends Activity {
	Data data = new Data(this);
	//DatabaseHelper Helper;
//	public static String userDate;
//	public static String userExpense;
//	public static String userCategory;
//	public static String userType;
//	public static String userSum;
//	
//	
//	
	public static TextView datatv2;
	public static TextView expensetv2;
	public static TextView categorytv2;
	public static TextView typetv2;
	public static TextView sumtv2;
	
	
	
	public static TextView datatv3;
	public static TextView expensetv3;
	public static TextView categorytv3;
	public static TextView typetv3;
	public static TextView sumtv3;
	
	
	public static TextView datatv4;
	public static TextView expensetv4;
	public static TextView categorytv4;
	public static TextView typetv4;
	public static TextView sumtv4;
	
	
	public static TextView datatv5;
	public static TextView expensetv5;
	public static TextView categorytv5;
	public static TextView typetv5;
	public static TextView sumtv5;
	
	
//	
//	public TestLabActivity tla=null;
//	public static DatabaseHelper dbhelper=null;
//	public static final String DATABASE_NAME = "dbForTest.db";
	public static final String TABLE_NAME = "diary";
//	
	
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list);
		data.open();
		
		 Cursor c = Data.db.query("diary", null, null, null, null, null, null);
		 // SQLiteDatabase listdb = Helper.getReadableDatabase();
		 // Cursor c = listdb.query(TABLE_NAME, null, null, null, null, null, null);
//		
//		while(c.moveToNext())
//		{
//			
		 
//		}
		    datatv2=(TextView)this.findViewById(R.id.RowSecondText1);
			
			expensetv2=(TextView)this.findViewById(R.id.RowSecondText2);
			
			categorytv2=(TextView)this.findViewById(R.id.RowSecondText3);
			
			sumtv2=(TextView)this.findViewById(R.id.RowSecondText4);

			typetv2=(TextView)this.findViewById(R.id.RowSecondText5);
			
			
			
			
			datatv3=(TextView)this.findViewById(R.id.RowThirdText1);
		
		    expensetv3=(TextView)this.findViewById(R.id.RowThirdText2);
		
			categorytv3=(TextView)this.findViewById(R.id.RowThirdText3);
			
			sumtv3=(TextView)this.findViewById(R.id.RowThirdText4);
	
		typetv3=(TextView)this.findViewById(R.id.RowThirdText5);
		
		
		
		
		datatv4=(TextView)this.findViewById(R.id.RowForthText1);
	
	   expensetv4=(TextView)this.findViewById(R.id.RowForthText2);
	
	  categorytv4=(TextView)this.findViewById(R.id.RowForthText3);
	
	  sumtv4=(TextView)this.findViewById(R.id.RowForthText4);

   	   typetv4=(TextView)this.findViewById(R.id.RowForthText5);
   	   
   	   
   	   
   	   
   	datatv5=(TextView)this.findViewById(R.id.RowFifthText1);
	
	expensetv5=(TextView)this.findViewById(R.id.RowFifthText2);
	
	categorytv5=(TextView)this.findViewById(R.id.RowFifthText3);
	
	sumtv5=(TextView)this.findViewById(R.id.RowFifthText4);

	typetv5=(TextView)this.findViewById(R.id.RowFifthText5);
		 
		 if(c.getCount()>0){
				c.moveToFirst();
				while(!c.isAfterLast()){
				try{	
					datatv2.setText(c.getString(c.getColumnIndex("Date")));			
					expensetv2.setText(c.getString(c.getColumnIndex("Expense")));
					categorytv2.setText(c.getString(c.getColumnIndex("Category")));
					typetv2.setText(c.getString(c.getColumnIndex("Type")));
					sumtv2.setText(c.getString(c.getColumnIndex("Sum")));
					
					c.moveToNext();
				
					datatv3.setText(c.getString(c.getColumnIndex("Date")));
					//datatv3.setText("sfsaf");
				    expensetv3.setText(c.getString(c.getColumnIndex("Expense")));
					categorytv3.setText(c.getString(c.getColumnIndex("Category")));
					typetv3.setText(c.getString(c.getColumnIndex("Type")));
					sumtv3.setText(c.getString(c.getColumnIndex("Sum")));
					c.moveToNext();
//					
					datatv4.setText(c.getString(c.getColumnIndex("Date")));
					expensetv4.setText(c.getString(c.getColumnIndex("Expense")));
					categorytv4.setText(c.getString(c.getColumnIndex("Category")));
					typetv4.setText(c.getString(c.getColumnIndex("Type")));
					sumtv4.setText(c.getString(c.getColumnIndex("Sum")));
					c.moveToNext();
////					
////					
					datatv5.setText(c.getString(c.getColumnIndex("Date")));
					expensetv5.setText(c.getString(c.getColumnIndex("Expense")));
					categorytv5.setText(c.getString(c.getColumnIndex("Category")));
				    typetv5.setText(c.getString(c.getColumnIndex("Type")));
				    sumtv5.setText(c.getString(c.getColumnIndex("Sum")));
 				    c.moveToNext();
				}catch(Exception ex)
				{
					
					
				}
					
				}
			}
			
		 
//		datatv2=(TextView)this.findViewById(R.id.RowSecondText1);
//		
//		expensetv2=(TextView)this.findViewById(R.id.RowSecondText2);
//		
//		categorytv2=(TextView)this.findViewById(R.id.RowSecondText3);
//		
//		sumtv2=(TextView)this.findViewById(R.id.RowSecondText5);
//
//		typetv2=(TextView)this.findViewById(R.id.RowSecondText4);
//		
		
	   // datatv2.setText(c.getString(c.getColumnIndex("Date")));

//		datatv3=(TextView)this.findViewById(R.id.RowThirdText1);
//		
//		expensetv3=(TextView)this.findViewById(R.id.RowThirdText2);
//		
//		categorytv3=(TextView)this.findViewById(R.id.RowThirdText3);
//		
//		sumtv3=(TextView)this.findViewById(R.id.RowThirdText5);
//
//		typetv3=(TextView)this.findViewById(R.id.RowThirdText4);
//		
//		
//		
//
//		datatv4=(TextView)this.findViewById(R.id.RowForthText1);
//		
//		expensetv4=(TextView)this.findViewById(R.id.RowForthText2);
//		
//		categorytv4=(TextView)this.findViewById(R.id.RowForthText3);
//		
//		sumtv4=(TextView)this.findViewById(R.id.RowForthText5);
//
//		typetv4=(TextView)this.findViewById(R.id.RowForthText4);
//		
//		

//		datatv5=(TextView)this.findViewById(R.id.RowFifthText1);
//		
//		expensetv5=(TextView)this.findViewById(R.id.RowFifthText2);
//		
//		categorytv5=(TextView)this.findViewById(R.id.RowFifthText3);
//		
//		sumtv5=(TextView)this.findViewById(R.id.RowFifthText5);
//
//		typetv5=(TextView)this.findViewById(R.id.RowFifthText4);
		
		
		
		
		
			
			  // datatv2.setText(c.getString(c.getColumnIndex("Date")));
//				expensetv2.setText(c.getString(c.getColumnIndex("Expense")));
//				categorytv2.setText(c.getString(c.getColumnIndex("Category")));
//				typetv2.setText(c.getString(c.getColumnIndex("Type")));
//				sumtv2.setText(c.getString(c.getColumnIndex("Sum")));
//				
//				c.moveToNext();
//				datatv3.setText(c.getString(c.getColumnIndex("Date")));
//				expensetv3.setText(c.getString(c.getColumnIndex("Expense")));
//				categorytv3.setText(c.getString(c.getColumnIndex("Category")));
//				typetv3.setText(c.getString(c.getColumnIndex("Type")));
//				sumtv3.setText(c.getString(c.getColumnIndex("Sum")));
//				
//				c.moveToNext();
//				datatv4.setText(c.getString(c.getColumnIndex("Date")));
//				expensetv4.setText(c.getString(c.getColumnIndex("Expense")));
//				categorytv4.setText(c.getString(c.getColumnIndex("Category")));
//				typetv4.setText(c.getString(c.getColumnIndex("Type")));
//				sumtv4.setText(c.getString(c.getColumnIndex("Sum")));
//				c.moveToNext();
//				
			
		
	}
//	public void query()
//	{
//		SQLiteDatabase listdb = dbhelper.getReadableDatabase();
//		ContentValues values=new ContentValues ();
//		
//		LinearLayout layout = new LinearLayout(this);
//		LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
//				ViewGroup.LayoutParams.FILL_PARENT,
//				ViewGroup.LayoutParams.FILL_PARENT); 
//		layout.setOrientation(LinearLayout.VERTICAL); 
//
//		
//		LinearLayout.LayoutParams txtParam = new LinearLayout.LayoutParams(
//				ViewGroup.LayoutParams.FILL_PARENT,
//				ViewGroup.LayoutParams.WRAP_CONTENT);
//		
//	
//		
//		Cursor cur = listdb.query("dbForTest", tla.col, null, null, null, null, null);
//	
//	    
//		
//		while(cur.moveToNext())
//		{
//			 userDate = cur.getString(cur.getColumnIndex("Date"));
//			 userExpense = cur.getString(cur.getColumnIndex("Expense"));
//			 userCategory  = cur.getString(cur.getColumnIndex("Category"));
//			 userType  = cur.getString(cur.getColumnIndex("Type"));
//			 userSum  = cur.getString(cur.getColumnIndex("Sum"));
//			 
//			 
//			 datetv.setText(userDate);
//			 expensetv.setText(userExpense);
//			 categorytv.setText(userCategory);
//			 typetv.setText(userType);
//			 sumtv.setText(userSum);
//			 
//			 datetv.setLayoutParams(txtParam);
//			 expensetv.setLayoutParams(txtParam);
//			 categorytv.setLayoutParams(txtParam);
//			 typetv.setLayoutParams(txtParam);
//			 sumtv.setLayoutParams(txtParam);
//			 
//			 
//			 layout.addView(datetv, txtParam); 
//			 layout.addView(expensetv, txtParam); 
//			 layout.addView(categorytv, txtParam); 
//			 layout.addView(typetv, txtParam); 
//			 layout.addView(sumtv, txtParam); 
//			 
//		}
//		//setTitle( userDate+"......."+userExpense+" information");
//		super.setContentView(layout, param); 
//	}
}