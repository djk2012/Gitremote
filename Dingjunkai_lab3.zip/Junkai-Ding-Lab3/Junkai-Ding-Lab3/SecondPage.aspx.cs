﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Junkai_Ding_Lab3
{
    public partial class SecondPage : System.Web.UI.Page
    {
     public  static String mileage = null;
      public  static  String Driverage = null;
      public  static  String Currentvalue = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GenderRadioButtonList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void secondconfirm_Click(object sender, EventArgs e)
        {
            mileage = this.miletextbox.Text;
            Driverage = this.driverTextBox.Text;
            Currentvalue = this.currentvaluetextbox.Text;
            Response.Redirect("ThirdPage.aspx");
        }
    }
}