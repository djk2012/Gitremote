﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
namespace Junkai_Ding_Lab3
{
    public partial class FirstPage : System.Web.UI.Page
    {
       public static  String owenername = null;
       public static String oweremail = null;
       public static String registrynumber = null;
       public static String manufactureyear = null;
       public static String numberofpassage = null;
       public static  String chosecar = null;
       public static String chosecarmode = null;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            manufactureyear = this.TextBox4.Text;
            numberofpassage = this.TextBox5.Text;
            owenername = TextBox1.Text;
            oweremail = TextBox2.Text;
            registrynumber = TextBox3.Text;
            Response.Redirect("SecondPage.aspx");
            
        }

        
        protected void AddItem(ListItem e)
        {


            if (this.carmanulist.SelectedIndex == 0)
            {
                e.Text = "V70";
                this.carmodelList.Items.Add(e);
                e.Text = "v40";
                this.carmodelList.Items.Add(e);
                e.Text = "xc90";
                this.carmodelList.Items.Add(e);
            }

            else if (this.carmanulist.SelectedIndex == 1)
            {
                e.Text = "Golf";
                this.carmodelList.Items.Add(e);
                e.Text = "Passat";
                this.carmodelList.Items.Add(e);
                e.Text = "Variant";
                this.carmodelList.Items.Add(e);
            }
            else if (this.carmanulist.SelectedIndex == 2)
            {
                e.Text = "190";
                this.carmodelList.Items.Add(e);
                e.Text = "220E";
                this.carmodelList.Items.Add(e);
                e.Text = "230D";
                this.carmodelList.Items.Add(e);
            }


        }

        protected void carmanulist_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.carmodelList.Items.Clear();
            if (this.carmanulist.SelectedIndex==0)
            {
                chosecar = "Volvo";
                ListItem l1=new ListItem();
                l1.Text="V70";
               chosecarmode = "v70";
                this.carmodelList.Items.Add(l1);
                ListItem l2 = new ListItem();
                l2.Text = "V40";
                 chosecarmode= "v40";
                this.carmodelList.Items.Add(l2);
                ListItem l3 = new ListItem();
                l3.Text = "xc90";
                 chosecarmode = "xc90";
                this.carmodelList.Items.Add(l3);
            }

            else if (this.carmanulist.SelectedIndex == 1)
            {
                chosecar = "VＷ";
                ListItem l1 = new ListItem();
                l1.Text = "Golf";
                chosecarmode ="Golf";
                this.carmodelList.Items.Add(l1);
                ListItem l2 = new ListItem();
                l2.Text = "Passat";
                chosecarmode = "Passat"; 
                this.carmodelList.Items.Add(l2);
                ListItem l3 = new ListItem();
                l3.Text = "Variant";
                chosecarmode = "Variant";
                this.carmodelList.Items.Add(l3);
            }
            else if (this.carmanulist.SelectedIndex == 2)
            {
                chosecar = "Mercedes";
                ListItem l1 = new ListItem();
                l1.Text = "190";
                chosecarmode = "190";
                this.carmodelList.Items.Add(l1);
                ListItem l2 = new ListItem();
                l2.Text = "220E";
                chosecarmode = "220";
                this.carmodelList.Items.Add(l2);
                ListItem l3 = new ListItem();
                l3.Text = "230D";
                chosecarmode = "230D";
                this.carmodelList.Items.Add(l3);
            }

        }

        protected void carmodelList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.carmanulist.SelectedIndex == 0)
            {
                if (this.carmodelList.SelectedIndex == 0)
                {
                    this.showImage.ImageUrl = "~/Images/volvov40.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 1)
                {
                    this.showImage.ImageUrl = "~/Images/volvov70.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 2)
                {
                    this.showImage.ImageUrl = "~/Images/volvov90.jpg";
                }

            }
            else if (this.carmanulist.SelectedIndex == 1)
            {
                if (this.carmodelList.SelectedIndex == 0)
                {
                    this.showImage.ImageUrl = "~/Images/vwgolf.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 1)
                {
                    this.showImage.ImageUrl = "~/Images/vwpassat.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 2)
                {
                    this.showImage.ImageUrl = "~/Images/vwvariant.jpg";
                }

            }
            else if (this.carmanulist.SelectedIndex == 2)
            {
                if (this.carmodelList.SelectedIndex == 0)
                {
                    this.showImage.ImageUrl = "~/Images/Mercedes190.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 1)
                {
                    this.showImage.ImageUrl = "~/Images/mercedes220e.jpg";
                }
                else if (this.carmodelList.SelectedIndex == 2)
                {
                    this.showImage.ImageUrl = "~/Images/mercedes230D.jpg";
                }

            }
        }
    }
}