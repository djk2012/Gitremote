﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
namespace Junkai_Ding_Lab3
{
    public partial class ThirdPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.TextBox1.Text = FirstPage.owenername + FirstPage.oweremail + FirstPage.registrynumber + FirstPage.manufactureyear+ FirstPage.numberofpassage + SecondPage.mileage + SecondPage.Driverage + SecondPage.Currentvalue;
        }
        public void calculate()
        {
            int manuyear = int.Parse(FirstPage.manufactureyear);
            int driverage = int.Parse(SecondPage.Driverage);
            double kilometer = double.Parse(SecondPage.mileage);

            int A = (2013 - manuyear) * 600;
            int B = 0;
            double C = 0;

            if (driverage < 45)
            {
                B = (50 - driverage) * 200;
            }
            else
            {
                B = (driverage - 40) * 225;
            }
            C = kilometer * 0.25;
            double sum = A + B + C;
            this.TextBox2.Text = "the insurance is " + sum;

            String fileName2 = Server.MapPath(@"TextFiles\login.txt");
            StreamWriter sw = new StreamWriter(fileName2, true);
            sw.WriteLine(FirstPage.owenername + "," + FirstPage.oweremail + "," + FirstPage.registrynumber+","+FirstPage.manufactureyear+","+FirstPage.numberofpassage +","+ SecondPage.mileage +","+ SecondPage.Driverage+"," + SecondPage.Currentvalue+","+sum);
            sw.Close();



            
        }

       
    }
}