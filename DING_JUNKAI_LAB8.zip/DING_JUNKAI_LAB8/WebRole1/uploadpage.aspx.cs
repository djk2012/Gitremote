﻿using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebRole1
{
    public partial class test : System.Web.UI.Page
    {
        blobs bl = new blobs();
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Label1.Text = Application["Rolename"].ToString();
        }
     
        protected void Upload_Click(object sender, EventArgs e)
        {

            CloudBlobContainer container = bl.GetCloudBlobContainer(this.Label1.Text);
            CloudBlob blob = container.GetBlobReference(imageFile.FileName.ToString());
            blob.Metadata["MetaName"] = "meta";
            BlobStream blobstream = blob.OpenWrite();
            blobstream.Write(imageFile.FileBytes,0,imageFile.FileBytes.Count());
            blobstream.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/showpage.aspx");
        }    
    }
}