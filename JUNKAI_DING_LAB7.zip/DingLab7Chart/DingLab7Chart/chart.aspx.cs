﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DingLab7Chart.WebReference;
namespace DingLab7Chart
{
    public partial class chart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Service1 ser = new Service1();


            for (int i = 2; i < 5; i++)
            {
                Chart1.Series["Series1"].Points.AddXY(ser.getnumberofchar(i, true), ser.getaccuracy(i, true));
            }

            for (int i = 2; i < 5; i++)
            {
                Chart2.Series["Series1"].Points.AddXY(i, ser.getSpeed(i, true));
            }

        }
    }
}