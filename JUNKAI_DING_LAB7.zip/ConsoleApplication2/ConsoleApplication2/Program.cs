﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleApplication2.WebReference2;

namespace ConsoleApplication2
{
    class Program
    {
      
        static void Main(string[] args)
        {
            Service1 ser = new Service1();
            Console.WriteLine(ser.GetHello());

            int i=3;
            while (i < 6)
            {
               
              
               Console.WriteLine("please input the question text");
               String questiontext=Console.ReadLine();
               ser.ExaminerSave(i,true,questiontext);
                
                i++;

            }
          // Console.WriteLine(ser.ExaminerRead(0,true));

        }
    }
}
