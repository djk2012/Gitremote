﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
namespace WCFServiceWebRole1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
       
        
        public string GetData(String  value)
        {

            return string.Format("You entered: {0}", value+"----->");
        }

        public string GetHello()
        {
           
            return "Hello from my WCF service in Windows Azure!";
        }


        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public String StudentRead(int questionid)
        {
            SqlConnection conn=null;
            try
            {
                conn= new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
            }
            catch (SqlException ex)
            {
                return ex+"errror has been appeared";
            }
             String sql="select * from question where questionid="+questionid+"";
            SqlCommand cmd = new SqlCommand(sql,conn);
            SqlDataReader reader = cmd.ExecuteReader();
            String questionword = null;
             while (reader.Read())
             {
                  questionword=reader.GetValue(1).ToString();
             }
             return questionword;
        }
        public String StudentSave(int id,String Examsend,String Stutype,String numchar,String speed,String accuracy)
        {
            try
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
                String sql = "insert into answer values(" + id + ",'" + Examsend+ "','"+Stutype+"','"+numchar+"','"+speed+"','"+accuracy+"')";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException ex)
            {
                return ex+" error has appeared";
            }
            //conn.close();
            return "you information has been saved !!";
        }
        public String ExaminerRead(int answerid)
        {
            String info = null;
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
            
            String sql = "select * from answer where Id="+ answerid;
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                info = "ID is :" + reader.GetValue(0) + " Examiner Send: " + reader.GetValue(1) + " Student Send : " + reader.GetValue(2) + " Number of char : " + reader.GetValue(3) + " Speed is : " + reader.GetValue(4) + " accurary is : " + reader.GetValue(5);
            }
            }
            catch (SqlException ex)
            {
                ex.ToString();
                conn.Close();
            }
           
            return info;
        }
        public String ExaminerSave(int questionid,String questiontext)
        {
            try
            {
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
                String sql = "insert into question values(" + questionid + ",'" + questiontext + "')";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }catch(SqlException Ex)
            {
                return Ex.ToString();
            }
            return " Examiner has saved succussfully!!";
        }

        public String getnumberofchar(int answerid)
        {
            String numberofchar =null;
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
            }
            catch (Exception ex)
            {
                
                return ex+"";
            }
            String sql = "select * from answer where Id=" + answerid + "";
            SqlCommand cmd = new SqlCommand(sql, conn);
           SqlDataReader reader = cmd.ExecuteReader();
           
            while (reader.Read())
            {
               numberofchar=Convert.ToString(reader.GetValue(3));
           }
            return numberofchar;
        }

        public String getaccuracy(int answerid)
        {
            String accuracy =null;
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
            }
            catch (SqlException ex)
            {
                
                return ex+" ";
            }
            String sql = "select * from answer where Id=" + answerid + "";
            SqlCommand cmd = new SqlCommand(sql, conn);
           SqlDataReader reader = cmd.ExecuteReader();
           
            while (reader.Read())
            {
                accuracy = Convert.ToString(reader.GetValue(5));
            }

            return accuracy;
        }

        public String getSpeed(int answerid)
        {
            String speed = null;
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection();
                conn.ConnectionString = "Data Source=pchgbayl1a.database.windows.net;Initial Catalog=dingdb;Persist Security Info=True;User ID=ding;Password=James123";
                conn.Open();
            }
            catch (SqlException ex)
            {

                return ex + " ";
            }
            String sql = "select * from answer where Id=" + answerid + "";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                speed = Convert.ToString(reader.GetValue(4));
            }

            return speed;
        }
        
    }
}