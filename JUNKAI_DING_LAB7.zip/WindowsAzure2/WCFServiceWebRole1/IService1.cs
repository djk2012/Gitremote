﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Collections;
namespace WCFServiceWebRole1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetHello();


        [OperationContract]
        string GetData(String value);

        [OperationContract]
        string ExaminerSave(int questionid,String questiontext);

        [OperationContract]
        string ExaminerRead(int answerid);

        [OperationContract]
        string StudentSave(int id, String Examsend, String Stutype, String numchar, String speed, String accuracy);


        [OperationContract]
        string StudentRead(int questionid);

        [OperationContract]
        string getnumberofchar(int answerid);

        [OperationContract]
        string getaccuracy(int answerid);

        [OperationContract]
        string getSpeed(int answerid);
       

       // [OperationContract]
       // CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
