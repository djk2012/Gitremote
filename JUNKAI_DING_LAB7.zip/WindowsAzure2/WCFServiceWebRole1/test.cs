﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace WCFServiceWebRole1
{
    public class test
    {
      
       
    }
}