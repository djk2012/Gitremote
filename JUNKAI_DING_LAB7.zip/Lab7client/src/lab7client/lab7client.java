/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7client;

import java.util.Scanner;

/**
 *
 * @author dingjunkai
 */
public class lab7client {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner sc=null;
       sc=new Scanner(System.in);
       System.out.println(getHello());
      int i=2;
      while(i<5)
      {
          String questiontext=studentRead(i);
          System.out.println("please input the word---->"+questiontext);
          long startime=System.nanoTime();
          String input= sc.next();
          float speed=(float)(System.nanoTime()-startime)/1000/1000/1000;
          float accuracy=getaccuracy(input,questiontext);
          System.out.println("Exminer send is : "+questiontext+"  student input is :"+input+" speed is  "+speed+" accuracy is : "+accuracy+" number of char is : "+questiontext.length());
          System.out.println(studentSave(i,questiontext,input,input.length()+"",speed+"",accuracy+""));
          i++;
      }
      
    
//       char[] chararr =null;
//       int count=0; 
//        long startTime=0;
//       String tx="text";
//       while(count<5)
//       {
//       System.out.println("please input the word "+tx);
//       startTime = System.nanoTime(); 
//       String input= sc.next();
//       double errcount=validateinput(input,tx);
//       System.out.println("you error number is: "+validateinput(input,tx));
//       System.out.println("The error rate is "+(errcount/tx.length()));
//       System.out.println("cost time is"+((System.nanoTime()-startTime)/1000));
//       
//       
//       
//       //System.out.println(getData(ss));
//       count++;
//       }
      
    }

    private static String getHello() {
        org.tempuri.Service1 service = new org.tempuri.Service1();
        org.tempuri.IService1 port = service.getBasicHttpBindingIService1();
        return port.getHello();
    }

   
    public static float getaccuracy(String input,String provide)
    {
      float accuarcy=0;
       float count=0;
        
       if(input.length()>=provide.length())
       {
           for(int i=0;i<provide.length();i++)
           {
              if(input.charAt(i)==provide.charAt(i))
              {
                  count++;
              }
           }
           int extra=input.length()-provide.length();
           accuarcy=count/(provide.length()+extra);
       }else{
            for(int i=0;i<input.length();i++)
           {
              if(input.charAt(i)!=provide.charAt(i))
              {
                  count++;
              }
           }
           int extra=provide.length()-input.length();
           accuarcy=count/(provide.length()+extra);
       }
        return accuarcy;
    }

    private static String studentRead(java.lang.Integer questionid) {
        org.tempuri.Service1 service = new org.tempuri.Service1();
        org.tempuri.IService1 port = service.getBasicHttpBindingIService1();
        return port.studentRead(questionid);
    }

  

    private static String examinerSave(java.lang.Integer questionid, java.lang.String questiontext) {
        org.tempuri.Service1 service = new org.tempuri.Service1();
        org.tempuri.IService1 port = service.getBasicHttpBindingIService1();
        return port.examinerSave(questionid, questiontext);
    }

    private static String examinerRead(java.lang.Integer answerid) {
        org.tempuri.Service1 service = new org.tempuri.Service1();
        org.tempuri.IService1 port = service.getBasicHttpBindingIService1();
        return port.examinerRead(answerid);
    }

    private static String studentSave(java.lang.Integer id, java.lang.String examsend, java.lang.String stutype, java.lang.String numchar, java.lang.String speed, java.lang.String accuracy) {
        org.tempuri.Service1 service = new org.tempuri.Service1();
        org.tempuri.IService1 port = service.getBasicHttpBindingIService1();
        return port.studentSave(id, examsend, stutype, numchar, speed, accuracy);
    }

   
   

    
}
