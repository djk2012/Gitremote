<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        
    </head>
    <body>
        
          


 <?php
 
   include 'index.php'; 

 
       
         $information=explode(".", $text);
         $correctinformation=explode(".", $correcttext);
         $choiceidinformation=  explode(".", $choiceidtext);
     foreach ($choiceidinformation as $infor)
     {
     echo $infor."</br>";
      }

        if($_REQUEST["1a"]== $correctinformation[0])
        {
 
        echo 'Question one number one correct';

        }
       else if($_REQUEST["1b"]==$correctinformation[0])
        {
            
           echo 'Question one number two correct';
        }
       else  if($_REQUEST["1c"]==$correctinformation[0])
        {  
           echo 'Question one number three correct';
        }
        
        if($_REQUEST["2a"]==$correctinformation[1])
        {          
           echo 'Question 2 number one correct';
        }
       else if($_REQUEST["2b"]==$correctinformation[1])
        {

            echo 'Question2 number two correct';
        }
       else  if($_REQUEST["2c"]==$correctinformation[1])
        {
             echo 'Question2 number three correct';
        }
        
         if($_REQUEST["3a"]==$correctinformation[2])
        {

           echo ' question 3 number one correct';          
        }
       else if($_REQUEST["3b"]==$correctinformation[2])
        {
            echo 'Question3 number two correct';
            
        }
       else  if($_REQUEST["3c"]==$correctinformation[2])
        {
  
          echo 'QUestion 3 number tree correct';
        }
        
        

  

      

     //  getResult();
        $con = mysql_connect("localhost", "root", "");
        if (!$con) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db("test", $con);
        $userName = $_POST["username"];
        
//       if (get_magic_quotes_gpc()) {
//        $userName = $_POST["username"];
//       } else {
//            $userName = addslashes($_POST["username"]);
//        }
        
        
        
         //sql injection2
//        $userName = cleanInput($_POST['username']); 
//        function cleanInput($input) {
//            $clean = strtolower($input);
//            $clean = preg_replace("/[^a-z]/", "", $clean);
//            $clean = substr($clean, 0, 10);
//            return $clean;
//        }
        
        //sql injection3
      //  $userName = $_POST["username"];
     //   $sql = "SELECT *  FROM users WHERE username='" . mysql_real_escape_string($userName) . "' limit 1";



       $sql = "SELECT * FROM users WHERE username = '$userName'";
         //$sql = "SELECT * FROM users WHERE username = 'maggie'";
        echo "Quering:  $sql <br/>";
        $result = mysql_query($sql);
        if(!$result){
            echo "Username: ".$userName." not found";
        }
        
        while ($row = mysql_fetch_array($result)) {
            echo $row['Full Name'] . " Your username: " . $row['username'] . " Your password: ".$row['password'];
            echo "<br />";
        }
        
        
        
        ?>
    </body>
</html>
