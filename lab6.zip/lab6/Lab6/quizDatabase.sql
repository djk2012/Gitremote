-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 04 mars 2013 kl 10:36
-- Serverversion: 5.5.24-log
-- PHP-version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databas: `quiz`
--

-- --------------------------------------------------------

--choices
-- Tabellstruktur `choices`
--

CREATE TABLE IF NOT EXISTS `choices` (
  `id` int(11) NOT NULL,
  `choice` varchar(256) COLLATE utf8_swedish_ci NOT NULL,
  `question` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `choices`
--

INSERT INTO `choices` (`id`, `choice`, `question`) VALUES
(1, 'Pretty hot Programmer', 1),
(2, 'PHP: Hypertext Preprocessor', 1),
(3, 'Personal Hypertext Processor', 1),
(4, '<?php>...</?>', 2),
(5, '<script>...</script>', 2),
(6, '<?php…?>', 2),
(7, '"Hello World";', 3),
(8, 'Document.Write("Hello World");', 3),
(9, 'echo "Hello World";', 3),
(10, '$', 4),
(11, '!', 4),
(12, '&', 4),
(13, 'Cascading Style Sheets', 5),
(14, 'Computer Style Sheets', 5),
(15, 'Creative Style Sheets', 5),
(16, '<stylesheet>mystyle.css</stylesheet />', 6),
(17, '<link rel="stylesheet" type="text/css" href="mystyle.css">', 6),
(18, '<style src="mystyle.css" />', 6);

-- --------------------------------------------------------

--
-- Tabellstruktur `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL,
  `text` varchar(256) COLLATE utf8_swedish_ci NOT NULL,
  `correct_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci COMMENT='All questions';

--
-- Dumpning av Data i tabell `questions`
--

INSERT INTO `questions` (`id`, `text`, `correct_id`) VALUES
(1, 'What does PHP stand for?', 2),
(2, 'PHP server scripts are surrounded by delimiters, which?', 6),
(3, 'How do you write "Hello World" in PHP', 9),
(4, 'All variables in PHP start with which symbol?', 10),
(5, 'What does CSS stand for?', 13),
(6, 'What is the correct HTML for referring to an external style sheet?', 17);

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(32) COLLATE utf8_swedish_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_swedish_ci NOT NULL,
  `Full Name` varchar(128) COLLATE utf8_swedish_ci NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`username`, `password`, `Full Name`) VALUES
('bart', 'password', 'Bartholomew Simpson '),
('granpa', 'zzzzzz', 'Abraham Simpson'),
('homer', 'abc123', 'Homer Simpson'),
('maggie', 'badpassword', 'Maggie Simpson'),
('Moe', 'ahjdlew32', 'Morris Lester Momar "Moe" Szyslak');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
