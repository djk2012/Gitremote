<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
          function cal($param) {
               
               $param=$param+1;
               echo $param;
    
        }
           $arr1=array();
           $arr1[0]="james";
           $arr1[1]="kobe";
           $arr1[2]="mike";
           for($a=0;$a<3;$a++){
               cal($a);
               echo "aaaaaaaaaaa</br>";
           }
           foreach ($arr1 as $a)
           {
               echo $a."</br>";
           }
           
           echo date("Y.m.d")."</br>";
            echo date("Y-m-d")."</br>";;
             echo date("Y/m/d")."</br>";;
           $tor=mktime(0,0,0,date("m")+1,date("d"),date("Y"))."</br>";;
echo "明天是 ".date("Y/m/d", $tor);
         
           
        ?>
      
        
    </body>
</html>
