<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Programming quiz</title>
       
       <link rel="stylesheet" type="text/css" href="style.css" />
    

    </head>
    <body>
 <?php
   

       
  
function getquestion()
  {
    //$a=0;
    $list=array();
    $con = mysql_connect("localhost", "root", "");
        if (!$con) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db("test", $con);
      ///  $userName = $_POST["id"];
       $number=  (int)rand(1, 6);
       echo $number."----------------------------------";
       $sql = "SELECT * FROM questions WHERE id =$number";
         //$sql = "SELECT * FROM users WHERE username = 'maggie'";
       
        $result = mysql_query($sql);
        if(!$result){
            echo " not found";
        }
        
        while ($row = mysql_fetch_array($result)) {
           
               $list[0]=$row["id"];
               $list[1]=$row["text"];
               $list[2]=$row["correct_id"];
               
              
//               $sql1="insert into outputquestion (id,question_id,corect_id,chose_id)values($a,$number, $list[2],0)";
//               mysql_query($sql1);
//               $a++;
        }
        return $list;
       
  }
  
  function getchoices($id)
  {
    $choicelist=array();
    
    $con = mysql_connect("localhost", "root", "");
        if (!$con) {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db("test", $con);
       $sql = "SELECT * FROM choices WHERE question =$id";
         //$sql = "SELECT * FROM users WHERE username = 'maggie'";
       
        $result = mysql_query($sql);
        if(!$result){
            echo " not found";
        }
        
        while ($row = mysql_fetch_array($result)) {
           
               $choicelist[]=$row["choice"];
               $choicelist[]=$row["id"];
              
        }
        return $choicelist;
       
  }
  
  
  
?>

        <div  class="content">
            <h1>This is a programming quiz</h1>
            <form action="quiz-result.php" method="post">
                           
                <div class="question" id="d1"style="word-break:break-all;">
                    
                      <?php 
 
            
                  
                  $qarr1=getquestion();                
                  $choicelist1 = getchoices($qarr1[0]);                
                  $qarr2=getquestion();                 
                  $choicelist2 = getchoices($qarr2[0]);                    
                  $qarr3=getquestion();        
                  $choicelist3 = getchoices($qarr3[0]);
                  
                  
                  $fullarray=array();
                  $fullarray[]=$qarr1[1];
                  $fullarray[]=".";
                  $fullarray[]=$choicelist1[0];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist1[2];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist1[4];
                   $fullarray[]=".";
                   
                  $fullarray[]=$qarr2[1];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist2[0];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist2[2];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist2[4];
                   $fullarray[]=".";
                  
                  $fullarray[]=$qarr3[1];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist3[0];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist3[2];
                   $fullarray[]=".";
                  $fullarray[]=$choicelist3[4];
                  
                  $text=  implode(".", $fullarray);
                  
                  $correctarr = array();
                  $correctarr[]=$qarr1[2];
                  $fullarray[]=".";
                  $correctarr[]=$qarr2[2];
                   $fullarray[]=".";
                  $correctarr[]=$qarr3[2];
                  
                 $correcttext=  implode(".", $correctarr);
                 
                 
                 $choicesidarr=array();
                 $choicesidarr[]=$choicelist1[1];
                 $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist1[3];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist1[5];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist2[1];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist2[3];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist2[5];
                   $choicesidarr[]=".";
                 
                 $choicesidarr[]=$choicelist3[1];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist3[3];
                   $choicesidarr[]=".";
                 $choicesidarr[]=$choicelist3[5];
                 
                 $choiceidtext=  implode(".", $choicesidarr);
                
                  
                  
                  
                  
                    ?>
                    <h2>Question 1</h2>

                    
                    
      
                    <ul class="inside">
                    <p><?php echo $qarr1[1]; ?></p>
                    <li> <input type="radio" id="1a"  name="1a"value="<?php $choicesidarr[1]?>"/> <label for="1a"><?php echo $choicelist1[0]?> 1a</label></li> 
                    <li> <input type="radio" id="1b"  name="1b" value="<?php $choicesidarr[3]?>"/> <label for="1b"><?php echo $choicelist1[2]?> 1b</label></li> 
                    <li> <input type="radio" id="1c"  name="1c" value="<?php $choicesidarr[5]?>"/> <label for="1c"><?php echo $choicelist1[4]?> 1c</label></li> 
                    
                    
                    </ul>
                    
                    
                </div>

                <div class="question" id="d2">
                    <h2>Question 2</h2>
                    <ul class="inside">
                    <p><?php echo $qarr2[1]; ?></p>
                    <li><input type="radio" id="2a" name="2a" value="<?php $choicesidarr[7]?>"/> <label  for="2a"><?php echo $choicelist2[0]?> 2a</label></li>
                    <li><input type="radio" id="2b"  name="2b"value="<?php $choicesidarr[9]?>"/> <label for="2b"><?php echo $choicelist2[2]?> 2b</label></li>
                    <li><input type="radio" id="2c"  name="2c" value="<?php $choicesidarr[11]?>"/> <label for="2c"><?php echo $choicelist2[4]?> 2c</label></li>
                     </ul>
                    
                </div>
                <div class="question" id="d3">
                    <h2>Question 3</h2>
                     <ul class="inside">
                    <p><?php echo $qarr3[1]; ?></p>
                     <li><input type="radio" id="3a"name="3a" value="<?php $choicesidarr[13]?>"/> <label for="3a"><?php echo $choicelist3[0]?> 3a</label></li>
                     <li><input type="radio" id="3b" name="3b" value="<?php $choicesidarr[15]?>"/> <label for="3b"><?php echo $choicelist3[2]?> 3b</label></li>
                     <li><input type="radio" id="3c" name="3c" value="<?php $choicesidarr[17]?>"/> <label for="3c"><?php echo $choicelist3[4]?> 3c</label></li>
                     </ul>
                </div>
                <input type="text" id="namebox" name="username" placeholder="Enter your name here" required="required"></input>
                
                <input type="submit" name="submitbt"value="Submit my answers"/>
               

                
                
            </form>
        </div>
        
    </body>
</html>
