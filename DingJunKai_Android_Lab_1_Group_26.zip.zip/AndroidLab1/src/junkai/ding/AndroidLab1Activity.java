package junkai.ding;

import java.util.Random;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AndroidLab1Activity extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
	private static final Random ran = new Random();
	private String [] str; 
    @Override
    
   
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button b1 =(Button)this.findViewById(R.id.b1);
        b1.setOnClickListener(this);
        
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//this.setTitle("")
		Resources re = getResources();
		str= re.getStringArray(R.array.Jokes);
	    String JokeContext= str[ran.nextInt(str.length)];
	    TextView tv2 = (TextView)this.findViewById(R.id.tv2);
	    tv2.setVisibility(0);
	    tv2.setText(JokeContext);
	    
		             
		
		
	}
}